<!DOCTYPE html>
<html>
<head>

  <title>psychometric-system</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">
  <script type="text/javascript" src="test.js"></script>

  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Psychometric - Index</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

</head>
<body>

  <header id="header" class="fixed-top d-flex align-items-center">
    <div class="container d-flex align-items-center">

      <div class="logo me-auto">
        <h1><a href="test.php">University Malaya</a></h1>
        <!-- Uncomment below if you prefer to use an image logo -->
        <!-- <a href="index.html"><img src="assets/img/logo.png" alt="" class="img-fluid"></a>-->
      </div>

      <nav id="navbar" class="navbar order-last order-lg-0">
        <ul>
          <li><a class="nav-link scrollto" href="adminhome.php">Home</a></li>
          <li><a class="nav-link scrollto" href="adminprofile.php">Student</a></li>
          <li class="dropdown"><a class="nav-link scrollto" href="#"><span>Manage Test</span><i class="bi bi-chevron-down"></i></a>
            <ul>
              <!-- <li><a href="addQuestion.php">Add Question</a></li> -->
              <li><a href="editQuestion.php">Edit Question</a></li>
            </ul>
          </li>
          <li><a class="nav-link scrollto" href="logout.php">Logout</a></li>
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav><!-- .navbar -->

    </div>
  </header>

  <div class="container d-flex justify-content-center align-items-center"
  style="min-height: 460vh">
  <div class="p-3">
    <h1 class="display-4 fs-1">All Questions</h1><br>

    <table class="table table-hover table table-bordered"
    style="width: 100%;background-color: LightGray"><h3>Integrity</h3>
    <thead class="thead-dark">
      <tr>
        <th scope="col">Question No.</th>
        <th scope="col">Question</th>
        <th scope="col">Edit</th>
        <!-- <th scope="col">Delete</th> -->
      </tr>
    </thead>

    <?php

    include "db_conn.php";

    $records = mysqli_query($conn,"select * from soalan where category='integrity'");

    while($data = mysqli_fetch_array($records))
    {
      ?>
      <tr>
        <td><?php echo $data['no_soalan']; ?></td>
        <td><?php echo $data['soalan']; ?></td>   
        <td><a href="edit.php?no_soalan=<?php echo $data['no_soalan']; ?>">Edit</a></td>
        <!-- <td><a href="delete.php?no_soalan=<?php echo $data['no_soalan']; ?>">Delete</a></td> -->

      </tr> 
      <?php
    }
    ?>

  </table>

  <table class="table table-hover table table-bordered"
  style="width: 100%;background-color: LightGray"><h3>Emotional</h3>
  <thead class="thead-dark">
      <tr>
        <th scope="col">Question No.</th>
        <th scope="col">Question</th>
        <th scope="col">Edit</th>
        <!-- <th scope="col">Delete</th> -->
      </tr>
    </thead>

  <?php

  include "db_conn.php";

  $records = mysqli_query($conn,"select * from soalan where category='emotional'");

  while($data = mysqli_fetch_array($records))
  {
    ?>
    <tr>
      <td><?php echo $data['no_soalan']; ?></td>
      <td><?php echo $data['soalan']; ?></td>   
      <td><a href="edit.php?no_soalan=<?php echo $data['no_soalan']; ?>">Edit</a></td>
      <!-- <td><a href="delete.php?no_soalan=<?php echo $data['no_soalan']; ?>">Delete</a></td> -->

    </tr> 
    <?php
  }
  ?>

</table>
<table class="table table-hover table table-bordered"
style="width: 100%;background-color: LightGray"><h3>Adaptability</h3>
<thead class="thead-dark">
      <tr>
        <th scope="col">Question No.</th>
        <th scope="col">Question</th>
        <th scope="col">Edit</th>
        <!-- <th scope="col">Delete</th> -->
      </tr>
    </thead>

<?php

include "db_conn.php";

$records = mysqli_query($conn,"select * from soalan where category='adaptability'");

while($data = mysqli_fetch_array($records))
{
  ?>
  <tr>
    <td><?php echo $data['no_soalan']; ?></td>
    <td><?php echo $data['soalan']; ?></td>   
    <td><a href="edit.php?no_soalan=<?php echo $data['no_soalan']; ?>">Edit</a></td>
    <!-- <td><a href="delete.php?no_soalan=<?php echo $data['no_soalan']; ?>">Delete</a></td> -->

  </tr> 
  <?php
}
?>

</table>
<table class="table table-hover table table-bordered"
style="width: 100%;background-color: LightGray"><h3>Mindfulness</h3>
<thead class="thead-dark">
      <tr>
        <th scope="col">Question No.</th>
        <th scope="col">Question</th>
        <th scope="col">Edit</th>
        <!-- <th scope="col">Delete</th> -->
      </tr>
    </thead>

<?php

include "db_conn.php";

$records = mysqli_query($conn,"select * from soalan where category='mindfulness'");

while($data = mysqli_fetch_array($records))
{
  ?>
  <tr>
    <td><?php echo $data['no_soalan']; ?></td>
    <td><?php echo $data['soalan']; ?></td>   
    <td><a href="edit.php?no_soalan=<?php echo $data['no_soalan']; ?>">Edit</a></td>
    <!-- <td><a href="delete.php?no_soalan=<?php echo $data['no_soalan']; ?>">Delete</a></td> -->

  </tr> 
  <?php
}
?>

</table>
<table class="table table-hover table table-bordered"
style="width: 100%;background-color: LightGray"><h3>Resilience</h3>
<thead class="thead-dark">
      <tr>
        <th scope="col">Question No.</th>
        <th scope="col">Question</th>
        <th scope="col">Edit</th>
        <!-- <th scope="col">Delete</th> -->
      </tr>
    </thead>

<?php

include "db_conn.php";

$records = mysqli_query($conn,"select * from soalan where category='resilience'");

while($data = mysqli_fetch_array($records))
{
  ?>
  <tr>
    <td><?php echo $data['no_soalan']; ?></td>
    <td><?php echo $data['soalan']; ?></td>   
    <td><a href="edit.php?no_soalan=<?php echo $data['no_soalan']; ?>">Edit</a></td>
    <!-- <td><a href="delete.php?no_soalan=<?php echo $data['no_soalan']; ?>">Delete</a></td> -->

  </tr> 
  <?php
}
?>

</table>
<table class="table table-hover table table-bordered"
style="width: 100%;background-color: LightGray"><h3>Communication</h3>
<thead class="thead-dark">
      <tr>
        <th scope="col">Question No.</th>
        <th scope="col">Question</th>
        <th scope="col">Edit</th>
        <!-- <th scope="col">Delete</th> -->
      </tr>
    </thead>

<?php

include "db_conn.php";

$records = mysqli_query($conn,"select * from soalan where category='communication'");

while($data = mysqli_fetch_array($records))
{
  ?>
  <tr>
    <td><?php echo $data['no_soalan']; ?></td>
    <td><?php echo $data['soalan']; ?></td>   
    <td><a href="edit.php?no_soalan=<?php echo $data['no_soalan']; ?>">Edit</a></td>
    <!-- <td><a href="delete.php?no_soalan=<?php echo $data['no_soalan']; ?>">Delete</a></td> -->

  </tr> 
  <?php
}
?>

</table>
<table class="table table-hover table table-bordered"
style="width: 100%;background-color: LightGray"><h3>Teamwork</h3>
<thead class="thead-dark">
      <tr>
        <th scope="col">Question No.</th>
        <th scope="col">Question</th>
        <th scope="col">Edit</th>
        <!-- <th scope="col">Delete</th> -->
      </tr>
    </thead>

<?php

include "db_conn.php";

$records = mysqli_query($conn,"select * from soalan where category='teamwork'");

while($data = mysqli_fetch_array($records))
{
  ?>
  <tr>
    <td><?php echo $data['no_soalan']; ?></td>
    <td><?php echo $data['soalan']; ?></td>   
    <td><a href="edit.php?no_soalan=<?php echo $data['no_soalan']; ?>">Edit</a></td>
    <!-- <td><a href="delete.php?no_soalan=<?php echo $data['no_soalan']; ?>">Delete</a></td> -->

  </tr> 
  <?php
}
?>

</table>
<table class="table table-hover table table-bordered"
style="width: 100%;background-color: LightGray"><h3>Creativity</h3>
<thead class="thead-dark">
      <tr>
        <th scope="col">Question No.</th>
        <th scope="col">Question</th>
        <th scope="col">Edit</th>
        <!-- <th scope="col">Delete</th> -->
      </tr>
    </thead>

<?php

include "db_conn.php";

$records = mysqli_query($conn,"select * from soalan where category='creativity'");

while($data = mysqli_fetch_array($records))
{
  ?>
  <tr>
    <td><?php echo $data['no_soalan']; ?></td>
    <td><?php echo $data['soalan']; ?></td>   
    <td><a href="edit.php?no_soalan=<?php echo $data['no_soalan']; ?>">Edit</a></td>
    <!-- <td><a href="delete.php?no_soalan=<?php echo $data['no_soalan']; ?>">Delete</a></td> -->

  </tr> 
  <?php
}
?>

</table>

</div>
</div>

</body>
</html>