<?php
include "db_conn.php";

$sql="SELECT * FROM answer";
$fire=mysqli_query($conn,$sql);


$query=$conn->query("select * from soalan where no_soalan='17'");
$res17=$query->fetch_array();

$query=$conn->query("select * from soalan where no_soalan='18'");
$res18=$query->fetch_array();

$query=$conn->query("select * from soalan where no_soalan='19'");
$res19=$query->fetch_array();

$query=$conn->query("select * from soalan where no_soalan='20'");
$res20=$query->fetch_array();

$query=$conn->query("select * from soalan where no_soalan='21'");
$res21=$query->fetch_array();

$query=$conn->query("select * from soalan where no_soalan='22'");
$res22=$query->fetch_array();

?>
<html>
<head>

  <title>psychometric-system</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">
  <script type="text/javascript" src="test.js"></script>

  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Psychometric - Index</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

  <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>

  <?php include("includes/style.php"); ?>
  
  <script type="text/javascript">
    google.charts.load('current', {'packages':['bar']});
    google.charts.setOnLoadCallback(drawChart);

    function drawChart() {
      var data = google.visualization.arrayToDataTable([
        ['Value', 'count'],
        <?php

        $query="SELECT likert.id AS answer17, COUNT(answer.qid) AS count FROM answer RIGHT JOIN likert ON likert.id=answer.answer17 GROUP BY likert.id";
        $query_result=mysqli_query($conn,$query);

        while ($result1=mysqli_fetch_assoc($query_result)) {
          
          echo "['".$result1['answer17']."',".$result1['count']."],";
          
        }
        ?>
        ]);

      var options = {
        chart: {
          title: '17.<?php echo $res17['soalan']; ?>',
        }
      };

      var chart = new google.charts.Bar(document.getElementById('graf17'));

      chart.draw(data, google.charts.Bar.convertOptions(options));
    }
  </script>

  <script type="text/javascript">
    google.charts.load('current', {'packages':['bar']});
    google.charts.setOnLoadCallback(drawChart);

    function drawChart() {
      var data = google.visualization.arrayToDataTable([
        ['Value', 'count'],
        <?php

        $query="SELECT likert.id AS answer18, COUNT(answer.qid) AS count FROM answer RIGHT JOIN likert ON likert.id=answer.answer18 GROUP BY likert.id";
        $query_result=mysqli_query($conn,$query);

        while ($result1=mysqli_fetch_assoc($query_result)) {
          
          echo "['".$result1['answer18']."',".$result1['count']."],";
          
        }
        ?>
        ]);

      var options = {
        chart: {
          title: '18.<?php echo $res18['soalan']; ?>',
        }
      };

      var chart = new google.charts.Bar(document.getElementById('graf18'));

      chart.draw(data, google.charts.Bar.convertOptions(options));
    }
  </script>

  <script type="text/javascript">
    google.charts.load('current', {'packages':['bar']});
    google.charts.setOnLoadCallback(drawChart);

    function drawChart() {
      var data = google.visualization.arrayToDataTable([
        ['Value', 'count'],
        <?php

        $query="SELECT likert.id AS answer19, COUNT(answer.qid) AS count FROM answer RIGHT JOIN likert ON likert.id=answer.answer19 GROUP BY likert.id";
        $query_result=mysqli_query($conn,$query);

        while ($result1=mysqli_fetch_assoc($query_result)) {
          
          echo "['".$result1['answer19']."',".$result1['count']."],";
          
        }
        ?>
        ]);

      var options = {
        chart: {
          title: '19.<?php echo $res19['soalan']; ?>',
        }
      };

      var chart = new google.charts.Bar(document.getElementById('graf19'));

      chart.draw(data, google.charts.Bar.convertOptions(options));
    }
  </script>

  <script type="text/javascript">
    google.charts.load('current', {'packages':['bar']});
    google.charts.setOnLoadCallback(drawChart);

    function drawChart() {
      var data = google.visualization.arrayToDataTable([
        ['Value', 'count'],
        <?php

        $query="SELECT likert.id AS answer20, COUNT(answer.qid) AS count FROM answer RIGHT JOIN likert ON likert.id=answer.answer20 GROUP BY likert.id";
        $query_result=mysqli_query($conn,$query);

        while ($result1=mysqli_fetch_assoc($query_result)) {
          
          echo "['".$result1['answer20']."',".$result1['count']."],";
          
        }
        ?>
        ]);

      var options = {
        chart: {
          title: '20.<?php echo $res20['soalan']; ?>',
        }
      };

      var chart = new google.charts.Bar(document.getElementById('graf20'));

      chart.draw(data, google.charts.Bar.convertOptions(options));
    }
  </script>

  <script type="text/javascript">
    google.charts.load('current', {'packages':['bar']});
    google.charts.setOnLoadCallback(drawChart);

    function drawChart() {
      var data = google.visualization.arrayToDataTable([
        ['Value', 'count'],
        <?php

        $query="SELECT likert.id AS answer21, COUNT(answer.qid) AS count FROM answer RIGHT JOIN likert ON likert.id=answer.answer21 GROUP BY likert.id";
        $query_result=mysqli_query($conn,$query);

        while ($result1=mysqli_fetch_assoc($query_result)) {
          
          echo "['".$result1['answer21']."',".$result1['count']."],";
          
        }
        ?>
        ]);

      var options = {
        chart: {
          title: '21.<?php echo $res21['soalan']; ?>',
        }
      };

      var chart = new google.charts.Bar(document.getElementById('graf21'));

      chart.draw(data, google.charts.Bar.convertOptions(options));
    }
  </script>

  <script type="text/javascript">
    google.charts.load('current', {'packages':['bar']});
    google.charts.setOnLoadCallback(drawChart);

    function drawChart() {
      var data = google.visualization.arrayToDataTable([
        ['Value', 'count'],
        <?php

        $query="SELECT likert.id AS answer22, COUNT(answer.qid) AS count FROM answer RIGHT JOIN likert ON likert.id=answer.answer22 GROUP BY likert.id";
        $query_result=mysqli_query($conn,$query);

        while ($result1=mysqli_fetch_assoc($query_result)) {
          
          echo "['".$result1['answer22']."',".$result1['count']."],";
          
        }
        ?>
        ]);

      var options = {
        chart: {
          title: '22.<?php echo $res22['soalan']; ?>',
        }
      };

      var chart = new google.charts.Bar(document.getElementById('graf22'));

      chart.draw(data, google.charts.Bar.convertOptions(options));
    }
  </script>



</head>
<body>
  <header id="header" class="fixed-top d-flex align-items-center">
    <div class="container d-flex align-items-center">

      <div class="logo me-auto">
        <h1><a href="test.php">Universiti Malaya</a></h1>
        <!-- Uncomment below if you prefer to use an image logo -->
        <!-- <a href="index.html"><img src="assets/img/logo.png" alt="" class="img-fluid"></a>-->
      </div>

      <nav id="navbar" class="navbar order-last order-lg-0">
        <ul>
          <li><a class="nav-link scrollto" href="adminhome.php">Home</a></li>
          <li><a class="nav-link scrollto" href="adminprofile.php">Student</a></li>          
          <li class="dropdown"><a class="nav-link scrollto" href="#"><span>Manage Test</span><i class="bi bi-chevron-down"></i></a>
            <ul>
              <!-- <li><a href="addQuestion.php">Add Question</a></li> -->
              <li><a href="editQuestion.php">Edit Question</a></li>
            </ul>
          </li>
          <li><a class="nav-link scrollto" href="logout.php">Logout</a></li>
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav><!-- .navbar -->

    </div>
  </header>  

  
  <!-- ======= Portfolio Section ======= -->
  <section id="portfolio" class="portfolio">
    <div class="container">

      <div class="section-title">
        <h2>REPORT</h2>
        <p><h4>Graph for MINDFULNESS</h4></p>
      </div>

      <div style="text-align: center;">
      <div id="graf17"style="text-align: center;width: 700px; height: 400px;margin: 70 auto;"></div>
      <div id="graf18"style="text-align: center;width: 700px;height: 400px; margin: 80 auto;"></div>
      <div id="graf19"style="text-align: center;width: 700px;height: 400px; margin: 80 auto;"></div>
      <div id="graf20"style="text-align: center;width: 700px;height: 400px; margin: 80 auto;"></div>
      <div id="graf21"style="text-align: center;width: 700px;height: 400px; margin: 80 auto;"></div>
      <div id="graf22"style="text-align: center;width: 700px;height: 400px; margin: 0 auto;"></div>

      <!-- <div class="p-3" id="graf17" style="width: 800px; height: 400px;"></div><br>

      <div class="p-3" id="graf18" style="width: 800px; height: 400px;"></div><br>

      <div class="p-3" id="graf19" style="width: 800px; height: 400px;"></div><br>

      <div class="p-3" id="graf20" style="width: 800px; height: 400px;"></div><br>

      <div class="p-3" id="graf21" style="width: 800px; height: 400px;"></div><br>

      <div class="p-3" id="graf22" style="width: 800px; height: 400px;"></div> -->

      <button style="margin-left:auto;margin-right:auto;display:block;margin-top:9%;"class="button button1"><a href="report.php">Back</button>
</div>
    </div>
  </section><!-- End Portfolio Section -->

<?php include("includes/footer.php"); ?>

</body>
</html>

