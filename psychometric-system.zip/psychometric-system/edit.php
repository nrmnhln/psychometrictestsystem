<?php
session_start();
include "db_conn.php"; // Using database connection file here

$no_soalan = $_GET['no_soalan']; // get id through query string

$qry = mysqli_query($conn,"select * from soalan where no_soalan='$no_soalan'"); // select query

$data = mysqli_fetch_array($qry); // fetch data

if(isset($_POST['update'])) // when click on Update button
{
    // $category=$_POST['category'];
    $soalan = $_POST['soalan'];
    $optionA= $_POST['optionA'];
    $optionB= $_POST['optionB'];
    $optionC= $_POST['optionC'];
    $optionD= $_POST['optionD'];
    $optionE= $_POST['optionE'];
    // $age = $_POST['age'];

    $edit = mysqli_query($conn,"update soalan set soalan='$soalan',optionA='$optionA', optionB='$optionB',optionC='$optionC' ,optionD='$optionD', optionE='$optionE' where no_soalan='$no_soalan'");

    if($edit)
    {
        mysqli_close($conn); // Close connection
        echo '<script type="text/javascript"> alert("Question Updated") </script>';
        echo'<script> window.location="editQuestion.php"; </script> ';
        
    }
    else
    {
        echo mysqli_error();
    }    	
}
?>

<!DOCTYPE html>
<html>
<head>

    <title>psychometric-system</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">
    <script type="text/javascript" src="test.js"></script>

    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">

    <title>Psychometric - Index</title>
    <meta content="" name="description">
    <meta content="" name="keywords">

    <!-- Favicons -->
    <link href="assets/img/favicon.png" rel="icon">
    <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

    <!-- Vendor CSS Files -->
    <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
    <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
    <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
    <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

    <!-- Template Main CSS File -->
    <link href="assets/css/style.css" rel="stylesheet">

</head>
<body>

    <header id="header" class="fixed-top d-flex align-items-center">
      <div class="container d-flex align-items-center">

        <div class="logo me-auto">
          <h1><a href="test.php">Universiti Malaya</a></h1>
          <!-- Uncomment below if you prefer to use an image logo -->
          <!-- <a href="index.html"><img src="assets/img/logo.png" alt="" class="img-fluid"></a>-->
      </div>

      <nav id="navbar" class="navbar order-last order-lg-0">
          <ul>
            <li><a class="nav-link scrollto" href="adminhome.php">Home</a></li>
            <li><a class="nav-link scrollto" href="adminprofile.php">View Student</a></li>
            <li class="dropdown"><a class="nav-link scrollto" href="#"><span>Manage Test</span><i class="bi bi-chevron-down"></i></a>
              <ul>
                <!-- <li><a href="addQuestion.php">Add Question</a></li> -->
                <li><a href="editQuestion.php">Edit Question</a></li>
            </ul>
        </li>
        <li><a class="nav-link scrollto" href="logout.php">Logout</a></li>
    </ul>
    <i class="bi bi-list mobile-nav-toggle"></i>
</nav><!-- .navbar -->

</div>
</header>

<div class="container d-flex align-items-center"
style="min-height: 115vh; align-content: center;">
<div class="p-5" style="margin-left:24%;margin-right:auto;display:block;">
    <h3>Update Question</h3>

    <form class="border shadow p-3 rounded" style="width: 200%; background-color: LightGray;" action="" method="POST">
        <table>
          <tr>
            <!-- <label for="Question No." 
            class="form-label ">Question No.</label>
            <input type="text" class="form-control" name="soalan" value="<?php echo $data['no_soalan'] ?>" placeholder="Edit Question" Required></td> -->

            
        <!--     <label class="form-label">Category</label>
            <select class="form-select mb-3"
            name="category"
            id="category" 
            aria-label="Default select example">
            <option value="integrity">Integrity</option>
            <option value="emotional">Emotional</option>
            <option value="adaptability">Adaptability</option>
            <option value="resilience">Resilience</option>
            <option value="creativity">Creativity</option>
            <option value="teamwork">Teamwork</option>
            <option value="communication">Communication</option>
            <option value="mindfulness">Mindfulness</option>
        </select> -->

        <label for="Question" 
        class="form-label ">Question</label>
        <input type="text" class="form-control" name="soalan" id="soalan" value="<?php echo $data['soalan'] ?>" placeholder="Edit Question" Required></td>

        <label for="Option A" 
        class="form-label ">Option A</label>
        <input type="text" class="form-control" name="optionA" id="optionA" value="<?php echo $data['optionA'] ?>" placeholder="Edit Question" Required></td>

        <label for="Option B" 
        class="form-label ">Option B</label>
        <input type="text" class="form-control" name="optionB" id="optionB" value="<?php echo $data['optionB'] ?>" placeholder="Edit Question" Required></td>

        <label for="Option C" 
        class="form-label ">Option C</label>
        <input type="text" class="form-control" name="optionC" id="optionC" value="<?php echo $data['optionC'] ?>" placeholder="Edit Question" Required></td>


        <label for="Option D" 
        class="form-label ">Option D</label>
        <input type="text" class="form-control" name="optionD" id="optionD" value="<?php echo $data['optionD'] ?>" placeholder="Edit Question" Required></td>

        <label for="Option E" 
        class="form-label ">Option E</label>
        <input type="text" class="form-control" name="optionE" id="optionE" value="<?php echo $data['optionE'] ?>" placeholder="Edit Question" Required></td>




        <div class="mb-3">
          <button type="submit" name="update" class="btn btn-default">Update Question</button>
          <button type="reset" class="btn btn-default"><a href="editQuestion.php">Cancel</a></button>
      </div>
  </tr>
</table>
</form>
</div>
</div>





</body>
</html>

