<?php
session_start();
include "db_conn.php";
if(isset($_SESSION['username']) && isset($_SESSION['role'])) {  ?>

      <!DOCTYPE html>
      <html>
      <head>

        <title>psychometric-system</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">
        <script type="text/javascript" src="test.js"></script>

        <meta charset="utf-8">
        <meta content="width=device-width, initial-scale=1.0" name="viewport">

        <title>Psychometric - Index</title>
        <meta content="" name="description">
        <meta content="" name="keywords">

        <!-- Favicons -->
        <link href="assets/img/favicon.png" rel="icon">
        <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

        <!-- Google Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

        <!-- Vendor CSS Files -->
        <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
        <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
        <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
        <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
        <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

        <!-- Template Main CSS File -->
        <link href="assets/css/style.css" rel="stylesheet">

      </head>
     <body>

      <!-- ======= Header ======= -->
  <header id="header" class="fixed-top d-flex align-items-center">
    <div class="container d-flex align-items-center">

      <div class="logo me-auto">
        <h1><a href="test.php">University Malaya</a></h1>
        <!-- Uncomment below if you prefer to use an image logo -->
        <!-- <a href="index.html"><img src="assets/img/logo.png" alt="" class="img-fluid"></a>-->
      </div>

      <nav id="navbar" class="navbar order-last order-lg-0">
        <ul>
          <li><a class="nav-link scrollto" href="adminhome.php">Home</a></li>
          <li><a class="nav-link scrollto active" href="#profile">Student</a></li>          
          <li class="dropdown"><a class="nav-link scrollto" href="#"><span>Manage Test</span><i class="bi bi-chevron-down"></i></a>
            <ul>
              <!-- <li><a href="addQuestion.php">Add Question</a></li> -->
              <li><a href="editQuestion.php">Edit Question</a></li>
            </ul>
          </li>
          <li><a class="nav-link scrollto" href="logout.php">Logout</a></li>
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav><!-- .navbar -->

    </div>
  </header>  


  <div class="container d-flex align-items-center"
  style="min-height: 200vh;">
  <?php if($_SESSION['role'] == 'admin') {?>
    <!-- for admin -->
    <!-- <div class="card" style="width: 20rem;  background-color: LightGray;">
      <img src="img/admin.png" 
      class="card-img-top" 
      alt="admin image">
      <div class="card-body text-center">
        <h5 class="card-title">
          <?=$_SESSION['name']?>
        </h5>
        <a href="logout.php" class="btn btn-dark">Logout</a>
      </div>
    </div>
 -->

    <div class="p-3">
      <?php include 'php/students.php';
      if (mysqli_num_rows($res) > 0 ) {?>
        <table class="table table-hover table table-bordered"
        style="width: 80%;  background-color: LightGray;">
        <h1 class="display-4 fs-1">All Students</h1>
        <thead class="thead-dark">
          <tr>
            <th scope="col">#</th>
            <th scope="col">Name</th>
            <th scope="col">Faculty</th>
            <th scope="col">Department</th>
            <th scope="col">Program</th>
            <th scope="col">Matric</th>
            <th scope="col">Year</th>
          </tr>
        </thead>
        <tbody>
          <?php
          $i = 1; 
          while ($rows = mysqli_fetch_assoc($res)) {?>
            <tr>
              <th scope="row"><?=$i?></th>
              <td><?=$rows['name']?></td>
              <td><?=$rows['faculty']?></td>
              <td><?=$rows['department']?></td>
              <td><?=$rows['program']?></td>
              <td><?=$rows['matric']?></td>
              <td><?=$rows['year']?></td>
            </tr>
            <?php $i++; }?>

          </tbody>
        </table>
      <?php }?>
    
      <?php 
      $query="SELECT * FROM answer";
      $result=mysqli_query($conn,$query);
      if (mysqli_num_rows($result) >0 ) {?>

            
            <table class="table table-hover table table-bordered"
            style="width: 80%; background-color: LightGray;">
            <h1 class="display-4 fs-1">Result</h1>
            <thead class="thead-dark">
              <tr>
                  <th scope="col">#</th>
                  <th scope="col">Matric</th>
                  <th scope="col">Integrity score</th>
                  <th scope="col">Emotional Intelligence score</th>
                  <th scope="col">Adaptability score</th>
                  <th scope="col">Mindfulness score</th>
                  <th scope="col">Resilience score</th>
                  <th scope="col">Communication score</th>
                  <th scope="col">Teamwork score</th>
                  <th scope="col">Creativity score</th>

            </tr>
      </thead>
      <tbody>
        <?php
        $i = 1; 
        while ($rows = mysqli_fetch_assoc($result)) {?>
          <tr>
            <th scope="row"><?=$i?></th>
            <td><?=$rows['matric']?></td>
            <td><?=$rows['average']?></td>
            <td><?=$rows['average2']?></td>
            <td><?=$rows['average3']?></td>
            <td><?=$rows['average4']?></td>
            <td><?=$rows['average5']?></td>
            <td><?=$rows['average6']?></td>
            <td><?=$rows['average7']?></td>
            <td><?=$rows['average8']?></td>

          </tr>
          <?php $i++; }?>

</tbody>
</table>
<?php }?>

</div>
  <?php }else { ?>
    <!-- for student -->

  </div>
<?php } ?>
</div>
<?php include("includes/footer.php"); ?>
</body>
</html>
<?php }else{
      header("Location: index.php");
} ?>


