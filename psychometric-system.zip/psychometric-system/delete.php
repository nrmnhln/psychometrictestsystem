<?php

include "db_conn.php"; // Using database connection file here

$no_soalan = $_GET['no_soalan']; // get id through query string

$del = mysqli_query($conn,"delete from soalan where no_soalan = '$no_soalan'"); // delete query

if($del)
{
    mysqli_close($conn); // Close connection
    header("location:editQuestion.php"); // redirects to all records page
    exit;	
}
else
{
    echo "Error deleting record"; // display error message if not delete
}
?>