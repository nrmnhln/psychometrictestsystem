<?php
session_start();
include "db_conn.php";
if(isset($_SESSION['username']) && isset($_SESSION['id'])) {  ?>

      <!DOCTYPE html>
      <html>
      <head>

        <title>psychometric-system</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">
        <script type="text/javascript" src="test.js"></script>

        <meta charset="utf-8">
        <meta content="width=device-width, initial-scale=1.0" name="viewport">

        <title>Psychometric - Index</title>
        <meta content="" name="description">
        <meta content="" name="keywords">

        <!-- Favicons -->
        <link href="assets/img/favicon.png" rel="icon">
        <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

        <!-- Google Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

        <!-- Vendor CSS Files -->
        <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
        <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
        <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
        <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
        <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

        <!-- Template Main CSS File -->
        <link href="assets/css/style.css" rel="stylesheet">

      </head>
     <body>
     	
<?php include("includes/header.php"); ?>


      <div class="container d-flex justify-content-center align-items-center"
      style="min-height: 130vh">

<div class="p-3">
      <?php include 'php/answer.php';
      if (mysqli_num_rows($result) > 0 ) {?>

            <h1 class="display-4 fs-1"><?=$_SESSION['name']?>'s Result</h1>
            <table class="table table-hover table table-bordered "
            style="width: 90%">
            <thead class="thead-dark">
              <tr>
                  <th scope="col">The Dimensions</th>
                  <th scope="col">Your Score</th>
                  <th scope="col">What the score means</th>

            </tr>
      </thead>
      <tbody>
      	<?php
      	$i = 1; 
      	while ($rows = mysqli_fetch_assoc($result)) {?>

      		<tr>
      			<th scope="col">Integrity</th>
      			<td><?=$rows['average']?></td>
      			<td><?=$rows['integrity']?></td>
      		</tr>

      		<tr>
      			<th scope="col">Emotional Intelligence</th>
      			<td><?=$rows['average2']?></td>
      			<td><?=$rows['emotional']?></td>
      		</tr>

          <tr>
            <th scope="col">Adaptability</th>
            <td><?=$rows['average3']?></td>
            <td><?=$rows['adapt']?></td>
          </tr>

          <tr>
            <th scope="col">Mindfulness</th>
            <td><?=$rows['average4']?></td>
            <td><?=$rows['mind']?></td>
          </tr>

          <tr>
            <th scope="col">Resilience</th>
            <td><?=$rows['average5']?></td>
            <td><?=$rows['resil']?></td>
          </tr>

          <tr>
            <th scope="col">Communication</th>
            <td><?=$rows['average6']?></td>
            <td><?=$rows['communi']?></td>
          </tr>

          <tr>
            <th scope="col">Teamwork</th>
            <td><?=$rows['average7']?></td>
            <td><?=$rows['team']?></td>
          </tr>

          <tr>
            <th scope="col">Creativity</th>
            <td><?=$rows['average8']?></td>
            <td><?=$rows['creative']?></td>
          </tr>

      		<?php $i++; }?>

</tbody>
</table>
<?php }?>
</div>

</div>
<?php } ?>
</div>

<?php include("includes/footer.php"); ?>

</body>
</html>

