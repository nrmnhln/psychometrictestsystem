<?php
session_start();
include "db_conn.php";
if(isset($_SESSION['username']) && isset($_SESSION['id'])) {  ?>

  <!DOCTYPE html>
  <html>
  <?php include("includes/head.php"); ?> 
  <body>

    <?php include("includes/header.php"); ?> 

    <div class="container d-flex justify-content-center align-items-center"
    style="min-height: 100vh">
    <?php if($_SESSION['role'] == 'admin') {?>
      <!-- for admin -->
      <div class="card" style="width: 18rem;">
        <img src="img/admin.png" 
        class="card-img-top" 
        alt="admin image">
        <div class="card-body text-center">
          <h5 class="card-title">
            <?=$_SESSION['name']?>
          </h5>
          <!-- <a href="logout.php" class="btn btn-dark">Logout</a> -->
        </div>
      </div>


      <div class="p-3">
        <?php include 'php/students.php';
        if (mysqli_num_rows($res) > 0 ) {?>

          <h1 class="display-4 fs-1">All students</h1>
          <table class="table"
          style="width: 32rem;">
          <thead>
            <tr>
              <th scope="col">#</th>
              <th scope="col">Name</th>
              <th scope="col">Username</th>
              <th scope="col">Role</th>
              <th scope="col">Faculty</th>
              <th scope="col">Department</th>
              <th scope="col">Program</th>
              <th scope="col">Matric</th>

            </tr>
          </thead>
          <tbody>
            <?php
            $i = 1; 
            while ($rows = mysqli_fetch_assoc($res)) {?>
              <tr>
                <th scope="row"><?=$i?></th>
                <td><?=$rows['name']?></td>
                <td><?=$rows['username']?></td>
                <td><?=$rows['role']?></td>
                <td><?=$rows['faculty']?></td>
                <td><?=$rows['department']?></td>
                <td><?=$rows['program']?></td>
                <td><?=$rows['matric']?></td>
              </tr>
              <?php $i++; }?>

            </tbody>
          </table>
        <?php }?>
      </div>

    <?php }else { ?>
      <!-- for student -->
      <div class="card" style="width: 20rem;">
        <img src="img/student.png" 
        class="card-img-top" 
        alt="student image">
        <div class="card-body text-center">
          <h5 class="card-title">
            <?=$_SESSION['name']?>
          </h5>
          <!-- <a href="logout.php" class="btn btn-dark">Logout</a> -->
        </div>
      </div>


      <div class="container d-flex justify-content-center align-items-center"
      style="min-height: 100vh ">
      <form class="border shadow p-3 rounded"
      action=""
      method="post" 
      style="width: 500px; background-color: LightGray;">
      <h1 class="text-center p-3">Profile</h1>

      <?php if (isset($_GET['error'])) { ?>
        <div class="alert alert-danger" role="alert">
          <?=$_GET['error']?>
        </div>
      <?php } ?>

      <div class="mb-3">
        <label for="faculty" 
        class="form-label "
        style="background-color: LightGray">Faculty</label>
        <input type="text"
        class="form-control" 
        name="faculty" 
        id="faculty"
        value="<?=$_SESSION['faculty']?>">
      </div>
      <div class="mb-3">
        <label for="department" 
        class="form-label"
        style="background-color: LightGray">Department</label>
        <input type="text"
        name="department" 
        class="form-control" 
        id="department"
        value="<?=$_SESSION['department']?>">
        <!-- value="<?php //if(isset($_POST['department'])) echo $_POST['department']; ?>" -->
      </div>
      <div class="mb-3">
        <label for="program" 
        class="form-label"
        style="background-color: LightGray">Program</label>
        <input type="text"
        name="program" 
        class="form-control" 
        id="program"
        value="<?=$_SESSION['program']?>">
      </div>
      <div class="mb-3">
        <label for="matric" 
        class="form-label"
        style="background-color: LightGray">Matric Number</label>
        <input type="text"
        name="matric" 
        class="form-control" 
        id="matric"
        value="<?=$_SESSION['matric']?>">
      </div>
      
      
      <input type="submit" name="update" value="Update"/>
      <!-- <a href="test.php" class="btn btn-dark">Submit</a> -->
    </form>
  </div>

</div>
<?php } ?>
</div>

<?php include("includes/footer.php"); ?>

</body>
</html>
<?php }else{
  header("Location: index.php");
} 
?>

<?php
if(!isset($_SESSION['id']))
{
  echo "<meta http-equiv='Refresh'";
  header("Location: index.php");
}

if(isset($_POST['update']))
{
  function test_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
  }

  $faculty = test_input($_POST['faculty']);
  $department = test_input($_POST['department']);
  $program = test_input($_POST['program']);
  $matric=(int)$_POST['matric'];
  $year = test_input($_POST['year']);

  if(empty($faculty) || empty($department) || empty($program) || empty($year) || empty($matric)) {

    echo '<script type="text/javascript"> alert("Please fill in the form with correct value")</script>';

  }else{

    $sql = "SELECT * FROM users WHERE matric='$matric'";
    $result= mysqli_query($conn, $sql);

    if(mysqli_num_rows($result) === 1) {
      
      $query="UPDATE users SET year='$_POST[year]', faculty='$_POST[faculty]', department='$_POST[department]', program='$_POST[program]' where matric='$_POST[matric]' ";
      $query_run=mysqli_query($conn,$query);

      if($query_run)
      {
        echo '<script type="text/javascript"> alert("Data Updated") </script>';
      }
      else
      {
        echo '<script type="text/javascript"> alert("Data Not Updated")</script>';
      }

    }else {
      $query1="INSERT INTO users VALUES year='$_POST[year]', faculty='$_POST[faculty]', department='$_POST[department]', program='$_POST[program]', matric='$_POST[matric]' ";
      $query_run=mysqli_query($conn,$query1);

      if($query_run)
      {
        echo '<script type="text/javascript"> alert("Data INSERted") </script>';
      }
      else
      {
        echo '<script type="text/javascript"> alert("Data Not inserted")</script>';
      }
    }

  }

}

?>