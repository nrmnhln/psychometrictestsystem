<?php
session_start();
include "db_conn.php";
if(isset($_SESSION['username']) && isset($_SESSION['id']) && isset($_SESSION['matric'])) {

  $matric=(int)$_SESSION['matric'];
  ?>


  <!DOCTYPE html>
  <html>
  <?php include("includes/head.php"); ?>

  <body>

    <?php include("includes/header.php"); ?>

    <!-- ======= Hero Section ======= -->
    <section id="hero" class="d-flex flex-column justify-content-center align-items-center">
      <div class="container text-center text-md-left" data-aos="fade-up">
        <h1>Psychometric Test</h1>
        <h2>Your personality matters</h2>    
      </div>
    </section><!-- End Hero -->

    <section id="test" class="test">
      <div class="container d-flex justify-content-center align-items-center"
      style="min-height: 90vh">
      <form class="border shadow p-3 rounded; form-disable"
      name="test1" 
      id="test1"
      action=""
      method="POST"
      style="background-color: LightGray;" >



      <table class="table table-hover table table-bordered "
      style="width: 80%">
      <div class="mb-3">
        <label for="matric" 
        class="form-label">Matric Number : </label>
        <input type="text"
        name="matric"
        id="matric"
        value="<?=$_SESSION['matric']?>"
        required="required"><br>
      </div>

      <!-- <div class="form-check form-check-inline"> -->
         <!-- INTEGRITY -->
        <?php
        $i=0;
        $query=$conn->query("select * from soalan where no_soalan='1'");
        $res1=$query->fetch_array();
        ?>

        <?php
        $i=0;
        $query=$conn->query("select * from soalan where no_soalan='2'");
        $res2=$query->fetch_array();
        ?>

        <?php
        $i=0;
        $query=$conn->query("select * from soalan where no_soalan='3'");
        $res3=$query->fetch_array();
        ?>

        <?php
        $i=0;
        $query=$conn->query("select * from soalan where no_soalan='4'");
        $res4=$query->fetch_array();
        ?>

        <?php
        $i=0;
        $query=$conn->query("select * from soalan where no_soalan='5'");
        $res5=$query->fetch_array();
        ?>
        
        <!-- ====================================================================================================== -->

        <!-- EMOTIONAL INTELLIGENCE -->
        <?php
        $i=0;
        $query=$conn->query("select * from soalan where no_soalan='6'");
        $res6=$query->fetch_array();
        ?>

        <?php
        $i=0;
        $query=$conn->query("select * from soalan where no_soalan='7'");
        $res7=$query->fetch_array();
        ?>

        <?php
        $i=0;
        $query=$conn->query("select * from soalan where no_soalan='8'");
        $res8=$query->fetch_array();
        ?>

        <?php
        $i=0;
        $query=$conn->query("select * from soalan where no_soalan='9'");
        $res9=$query->fetch_array();
        ?>

        <?php
        $i=0;
        $query=$conn->query("select * from soalan where no_soalan='10'");
        $res10=$query->fetch_array();
        ?>

        <?php
        $i=0;
        $query=$conn->query("select * from soalan where no_soalan='11'");
        $res11=$query->fetch_array();
        ?>
        <!-- ========================================================================================================= -->

        <!-- ADAPTABILITY -->
        <?php
        $i=0;
        $query=$conn->query("select * from soalan where no_soalan='12'");
        $res12=$query->fetch_array();
        ?>

        <?php
        $i=0;
        $query=$conn->query("select * from soalan where no_soalan='13'");
        $res13=$query->fetch_array();
        ?>

        <?php
        $i=0;
        $query=$conn->query("select * from soalan where no_soalan='14'");
        $res14=$query->fetch_array();
        ?>

        <?php
        $i=0;
        $query=$conn->query("select * from soalan where no_soalan='15'");
        $res15=$query->fetch_array();
        ?>

        <?php
        $i=0;
        $query=$conn->query("select * from soalan where no_soalan='16'");
        $res16=$query->fetch_array();
        ?>
        <!-- ========================================================================================================== -->

        <!-- MINDFULNESS -->
        <?php
        $i=0;
        $query=$conn->query("select * from soalan where no_soalan='17'");
        $res17=$query->fetch_array();
        ?>

        <?php
        $i=0;
        $query=$conn->query("select * from soalan where no_soalan='18'");
        $res18=$query->fetch_array();
        ?>

        <?php
        $i=0;
        $query=$conn->query("select * from soalan where no_soalan='19'");
        $res19=$query->fetch_array();
        ?>

        <?php
        $i=0;
        $query=$conn->query("select * from soalan where no_soalan='20'");
        $res20=$query->fetch_array();
        ?>

        <?php
        $i=0;
        $query=$conn->query("select * from soalan where no_soalan='21'");
        $res21=$query->fetch_array();
        ?>

        <?php
        $i=0;
        $query=$conn->query("select * from soalan where no_soalan='22'");
        $res22=$query->fetch_array();
        ?>
        <!-- ========================================================================================================= -->

        <!-- RESILIENCE -->
        <?php
        $i=0;
        $query=$conn->query("select * from soalan where no_soalan='23'");
        $res23=$query->fetch_array();
        ?>

        <?php
        $i=0;
        $query=$conn->query("select * from soalan where no_soalan='24'");
        $res24=$query->fetch_array();
        ?>

        <?php
        $i=0;
        $query=$conn->query("select * from soalan where no_soalan='25'");
        $res25=$query->fetch_array();
        ?>

        <?php
        $i=0;
        $query=$conn->query("select * from soalan where no_soalan='26'");
        $res26=$query->fetch_array();
        ?>

        <?php
        $i=0;
        $query=$conn->query("select * from soalan where no_soalan='27'");
        $res27=$query->fetch_array();
        ?>

        <?php
        $i=0;
        $query=$conn->query("select * from soalan where no_soalan='28'");
        $res28=$query->fetch_array();
        ?>
        <!-- ========================================================================================================= -->

        <!-- COMMUNICATION -->
        <?php
        $i=0;
        $query=$conn->query("select * from soalan where no_soalan='29'");
        $res29=$query->fetch_array();
        ?>

        <?php
        $i=0;
        $query=$conn->query("select * from soalan where no_soalan='30'");
        $res30=$query->fetch_array();
        ?>

        <?php
        $i=0;
        $query=$conn->query("select * from soalan where no_soalan='31'");
        $res31=$query->fetch_array();
        ?>

        <?php
        $i=0;
        $query=$conn->query("select * from soalan where no_soalan='32'");
        $res32=$query->fetch_array();
        ?>

        <?php
        $i=0;
        $query=$conn->query("select * from soalan where no_soalan='33'");
        $res33=$query->fetch_array();
        ?>

        <?php
        $i=0;
        $query=$conn->query("select * from soalan where no_soalan='34'");
        $res34=$query->fetch_array();
        ?>
        <!-- ========================================================================================================= -->

        <!-- TEAMWORK -->
        <?php
        $i=0;
        $query=$conn->query("select * from soalan where no_soalan='35'");
        $res35=$query->fetch_array();
        ?>

        <?php
        $i=0;
        $query=$conn->query("select * from soalan where no_soalan='36'");
        $res36=$query->fetch_array();
        ?>

        <?php
        $i=0;
        $query=$conn->query("select * from soalan where no_soalan='37'");
        $res37=$query->fetch_array();
        ?>

        <?php
        $i=0;
        $query=$conn->query("select * from soalan where no_soalan='38'");
        $res38=$query->fetch_array();
        ?>

        <?php
        $i=0;
        $query=$conn->query("select * from soalan where no_soalan='39'");
        $res39=$query->fetch_array();
        ?>

        <?php
        $i=0;
        $query=$conn->query("select * from soalan where no_soalan='40'");
        $res40=$query->fetch_array();
        ?>
        <!-- ========================================================================================================= -->

        <!-- CREATIVITY -->
        <?php
        $i=0;
        $query=$conn->query("select * from soalan where no_soalan='41'");
        $res41=$query->fetch_array();
        ?>

        <?php
        $i=0;
        $query=$conn->query("select * from soalan where no_soalan='42'");
        $res42=$query->fetch_array();
        ?>

        <?php
        $i=0;
        $query=$conn->query("select * from soalan where no_soalan='43'");
        $res43=$query->fetch_array();
        ?>

        <?php
        $i=0;
        $query=$conn->query("select * from soalan where no_soalan='44'");
        $res44=$query->fetch_array();
        ?>

        <?php
        $i=0;
        $query=$conn->query("select * from soalan where no_soalan='45'");
        $res45=$query->fetch_array();
        ?>
        <!-- ========================================================================================================= -->

        <table class="table table-hover table table-bordered"
        style="width: 100%;"><h3>Integrity</h3>
        <thead class="thead-dark">
          <tr>
            <th scope="col">Ques No.</th>
            <th scope="col">Question</th>
            <th scope="col">Strongly Disagree</th>
            <th scope="col">Disagree</th>
            <th scope="col">Neutral</th>
            <th scope="col">Agree</th>
            <th scope="col">Strongly Agree</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td><?=$res1['no_soalan']?></td>
            <td><?=$res1['soalan']?></td>
            <td>
              <?php
              $i=0;
              $query=$conn->query("select * from answer where matric='$matric'");
              $result=$query->fetch_array();
              ?>
              <input type="radio" name="answer1" <?php if($result['answer1']=="1") echo "checked";?> value="1" onclick="itemclicked('answer1');" ></td>
              <td><input type="radio" name="answer1" <?php if($result['answer1']=="2") echo "checked";?> value="2" onclick="itemclicked('answer1');"></td>
              <td><input type="radio" name="answer1" <?php if($result['answer1']=="3") echo "checked";?> value="3" onclick="itemclicked('answer1');"></td>
              <td><input type="radio" name="answer1" <?php if($result['answer1']=="4") echo "checked";?> value="4" onclick="itemclicked('answer1');"></td>
              <td><input type="radio" name="answer1" <?php if($result['answer1']=="5") echo "checked";?> value="5" onclick="itemclicked('answer1');"></td>
            </tr>
          </tbody>

          <tbody>
            <tr>
              <td><?=$res2['no_soalan']?></td>
              <td><?=$res2['soalan']?></td>
              <td><input type="radio" name="answer2" <?php if($result['answer2']=="1") echo "checked";?> value="1" onclick="itemclicked('answer2');"></td>
              <td><input type="radio" name="answer2" <?php if($result['answer2']=="2") echo "checked";?> value="2" onclick="itemclicked('answer2');" ></td>
              <td><input type="radio" name="answer2" <?php if($result['answer2']=="3") echo "checked";?> value="3" onclick="itemclicked('answer2');" ></td>
              <td><input type="radio" name="answer2" <?php if($result['answer2']=="4") echo "checked";?> value="4" onclick="itemclicked('answer2');" ></td>
              <td><input type="radio" name="answer2" <?php if($result['answer2']=="5") echo "checked";?> value="5" onclick="itemclicked('answer2');"></td>
            </tr>
          </tbody>

          <tbody>
            <tr>
              <td><?=$res3['no_soalan']?></td>
              <td><?=$res3['soalan']?></td>
              <td><input type="radio" name="answer3" <?php if($result['answer3']=="1") echo "checked";?> value="1" onclick="itemclicked('answer3');"></td>
              <td><input type="radio" name="answer3" <?php if($result['answer3']=="2") echo "checked";?> value="2" onclick="itemclicked('answer3');"></td>
              <td><input type="radio" name="answer3" <?php if($result['answer3']=="3") echo "checked";?> value="3" onclick="itemclicked('answer3');"></td>
              <td><input type="radio" name="answer3" <?php if($result['answer3']=="4") echo "checked";?> value="4" onclick="itemclicked('answer3');"></td>
              <td><input type="radio" name="answer3" <?php if($result['answer3']=="5") echo "checked";?> value="5" onclick="itemclicked('answer3');"></td>
            </tr>
          </tbody>

          <tbody>
            <tr>
              <td><?=$res4['no_soalan']?></td>
              <td><?=$res4['soalan']?></td>
              <td><input type="radio" name="answer4" <?php if($result['answer4']=="1") echo "checked";?> value="1" onclick="itemclicked('answer4');"></td>
              <td><input type="radio" name="answer4" <?php if($result['answer4']=="2") echo "checked";?> value="2" onclick="itemclicked('answer4');"></td>
              <td><input type="radio" name="answer4" <?php if($result['answer4']=="3") echo "checked";?> value="3" onclick="itemclicked('answer4');"></td>
              <td><input type="radio" name="answer4" <?php if($result['answer4']=="4") echo "checked";?> value="4" onclick="itemclicked('answer4');"></td>
              <td><input type="radio" name="answer4" <?php if($result['answer4']=="5") echo "checked";?> value="5" onclick="itemclicked('answer4');"></td>
            </tr>
          </tbody>

          <tbody>
            <tr>
              <td><?=$res5['no_soalan']?></td>
              <td><?=$res5['soalan']?></td>
              <td><input type="radio" name="answer5" <?php if($result['answer5']=="1") echo "checked";?> value="1" onclick="itemclicked('answer5');"></td>
              <td><input type="radio" name="answer5" <?php if($result['answer5']=="2") echo "checked";?> value="2" onclick="itemclicked('answer5');"></td>
              <td><input type="radio" name="answer5" <?php if($result['answer5']=="3") echo "checked";?> value="3" onclick="itemclicked('answer5');"></td>
              <td><input type="radio" name="answer5" <?php if($result['answer5']=="4") echo "checked";?> value="4" onclick="itemclicked('answer5');"></td>
              <td><input type="radio" name="answer5" <?php if($result['answer5']=="5") echo "checked";?> value="5" onclick="itemclicked('answer5');"></td>
            </tr>
          </tbody>
        </table>


        <!-- ======================================================================================================================= -->

        <table class="table table-hover table table-bordered"
        style="width: 100%;"><h3>Emotional Intelligence</h3>

        <thead class="thead-dark">
          <tr>
            <th scope="col">Ques No.</th>
            <th scope="col">Question</th>
            <th scope="col">Strongly Disagree</th>
            <th scope="col">Disagree</th>
            <th scope="col">Neutral</th>
            <th scope="col">Agree</th>
            <th scope="col">Strongly Agree</th>
          </tr>
        </thead>

        <tbody>
          <tr>
            <td><?=$res6['no_soalan']?></td>
            <td><?=$res6['soalan']?></td>
            <td><input type="radio" name="answer6" <?php if($result['answer6']=="1") echo "checked";?> value="1" onclick="itemclicked('answer6');" ></td>
            <td><input type="radio" name="answer6" <?php if($result['answer6']=="2") echo "checked";?> value="2" onclick="itemclicked('answer6');" ></td>
            <td><input type="radio" name="answer6" <?php if($result['answer6']=="3") echo "checked";?> value="3" onclick="itemclicked('answer6');" ></td>
            <td><input type="radio" name="answer6" <?php if($result['answer6']=="4") echo "checked";?> value="4" onclick="itemclicked('answer6');" ></td>
            <td><input type="radio" name="answer6" <?php if($result['answer6']=="5") echo "checked";?> value="5" onclick="itemclicked('answer6');"></td>
          </tr>
        </tbody>

        <tbody>
          <tr>
            <td><?=$res7['no_soalan']?></td>
            <td><?=$res7['soalan']?></td>
            <td><input type="radio" name="answer7" <?php if($result['answer7']=="1") echo "checked";?> value="1" onclick="itemclicked('answer7');" ></td>
            <td><input type="radio" name="answer7" <?php if($result['answer7']=="2") echo "checked";?> value="2" onclick="itemclicked('answer7');" ></td>
            <td><input type="radio" name="answer7" <?php if($result['answer7']=="3") echo "checked";?> value="3" onclick="itemclicked('answer7');" ></td>
            <td><input type="radio" name="answer7" <?php if($result['answer7']=="4") echo "checked";?> value="4" onclick="itemclicked('answer7');" ></td>
            <td><input type="radio" name="answer7" <?php if($result['answer7']=="5") echo "checked";?> value="5" onclick="itemclicked('answer7');" ></td>
          </tr>
        </tbody>

        <tbody>
          <tr>
            <td><?=$res8['no_soalan']?></td>
            <td><?=$res8['soalan']?></td>
            <td><input type="radio" name="answer8" <?php if($result['answer8']=="1") echo "checked";?> value="1" onclick="itemclicked('answer8');" ></td>
            <td><input type="radio" name="answer8" <?php if($result['answer8']=="2") echo "checked";?> value="2" onclick="itemclicked('answer8');" ></td>
            <td><input type="radio" name="answer8" <?php if($result['answer8']=="3") echo "checked";?> value="3" onclick="itemclicked('answer8');" ></td>
            <td><input type="radio" name="answer8" <?php if($result['answer8']=="4") echo "checked";?> value="4" onclick="itemclicked('answer8');" ></td>
            <td><input type="radio" name="answer8" <?php if($result['answer8']=="5") echo "checked";?> value="5" onclick="itemclicked('answer8');" ></td>
          </tr>
        </tbody>

        <tbody>
          <tr>
            <td><?=$res9['no_soalan']?></td>
            <td><?=$res9['soalan']?></td>
            <td><input type="radio" name="answer9" <?php if($result['answer9']=="1") echo "checked";?> value="1" onclick="itemclicked('answer9');" ></td>
            <td><input type="radio" name="answer9" <?php if($result['answer9']=="2") echo "checked";?> value="2" onclick="itemclicked('answer9');" ></td>
            <td><input type="radio" name="answer9" <?php if($result['answer9']=="3") echo "checked";?> value="3" onclick="itemclicked('answer9');" ></td>
            <td><input type="radio" name="answer9" <?php if($result['answer9']=="4") echo "checked";?> value="4" onclick="itemclicked('answer9');" ></td>
            <td><input type="radio" name="answer9" <?php if($result['answer9']=="5") echo "checked";?> value="5" onclick="itemclicked('answer9');" ></td>
          </tr>
        </tbody>

        <tbody>
          <tr>
            <td><?=$res10['no_soalan']?></td>
            <td><?=$res10['soalan']?></td>
            <td><input type="radio" name="answer10" <?php if($result['answer10']=="1") echo "checked";?> value="1" onclick="itemclicked('answer10');" ></td>
            <td><input type="radio" name="answer10" <?php if($result['answer10']=="2") echo "checked";?> value="2" onclick="itemclicked('answer10');" ></td>
            <td><input type="radio" name="answer10" <?php if($result['answer10']=="3") echo "checked";?> value="3" onclick="itemclicked('answer10');" ></td>
            <td><input type="radio" name="answer10" <?php if($result['answer10']=="4") echo "checked";?> value="4" onclick="itemclicked('answer10');" ></td>
            <td><input type="radio" name="answer10" <?php if($result['answer10']=="5") echo "checked";?> value="5" onclick="itemclicked('answer10');" ></td>
          </tr>
        </tbody>

        <tbody>
          <tr>
            <td><?=$res11['no_soalan']?></td>
            <td><?=$res11['soalan']?></td>
            <td><input type="radio" name="answer11" <?php if($result['answer11']=="1") echo "checked";?> value="1" onclick="itemclicked('answer11');" ></td>
            <td><input type="radio" name="answer11" <?php if($result['answer11']=="2") echo "checked";?> value="2" onclick="itemclicked('answer11');" ></td>
            <td><input type="radio" name="answer11" <?php if($result['answer11']=="3") echo "checked";?> value="3" onclick="itemclicked('answer11');" ></td>
            <td><input type="radio" name="answer11" <?php if($result['answer11']=="4") echo "checked";?> value="4" onclick="itemclicked('answer11');" ></td>
            <td><input type="radio" name="answer11" <?php if($result['answer11']=="5") echo "checked";?> value="5" onclick="itemclicked('answer11');" ></td>
          </tr>
        </tbody>
      </table>
      <!-- ======================================================================================================================== -->
      
      <table class="table table-hover table table-bordered"
        style="width: 100%;"><h3>Adaptability</h3>

        <thead class="thead-dark">
          <tr>
            <th scope="col">Ques No.</th>
            <th scope="col">Question</th>
            <th scope="col">Strongly Disagree</th>
            <th scope="col">Disagree</th>
            <th scope="col">Neutral</th>
            <th scope="col">Agree</th>
            <th scope="col">Strongly Agree</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td><?=$res12['no_soalan']?></td>
            <td><?=$res12['soalan']?></td>
            <td><input type="radio" name="answer12" <?php if($result['answer12']=="1") echo "checked";?> value="1" onclick="itemclicked('answer12');" ></td>
            <td><input type="radio" name="answer12" <?php if($result['answer12']=="2") echo "checked";?> value="2" onclick="itemclicked('answer12');" ></td>
            <td><input type="radio" name="answer12" <?php if($result['answer12']=="3") echo "checked";?> value="3" onclick="itemclicked('answer12');" ></td>
            <td><input type="radio" name="answer12" <?php if($result['answer12']=="4") echo "checked";?> value="4" onclick="itemclicked('answer12');" ></td>
            <td><input type="radio" name="answer12" <?php if($result['answer12']=="5") echo "checked";?> value="5" onclick="itemclicked('answer12');" ></td>
          </tr>
        </tbody>

        <tbody>
          <tr>
            <td><?=$res13['no_soalan']?></td>
            <td><?=$res13['soalan']?></td>
            <td><input type="radio" name="answer13" <?php if($result['answer13']=="1") echo "checked";?> value="1" onclick="itemclicked('answer13');" ></td>
            <td><input type="radio" name="answer13" <?php if($result['answer13']=="2") echo "checked";?> value="2" onclick="itemclicked('answer13');" ></td>
            <td><input type="radio" name="answer13" <?php if($result['answer13']=="3") echo "checked";?> value="3" onclick="itemclicked('answer13');" ></td>
            <td><input type="radio" name="answer13" <?php if($result['answer13']=="4") echo "checked";?> value="4" onclick="itemclicked('answer13');" ></td>
            <td><input type="radio" name="answer13" <?php if($result['answer13']=="5") echo "checked";?> value="5" onclick="itemclicked('answer13');" ></td>
          </tr>
        </tbody>

        <tbody>
          <tr>
            <td><?=$res14['no_soalan']?></td>
            <td><?=$res14['soalan']?></td>
            <td><input type="radio" name="answer14" <?php if($result['answer14']=="1") echo "checked";?> value="1" onclick="itemclicked('answer14');" ></td>
            <td><input type="radio" name="answer14" <?php if($result['answer14']=="2") echo "checked";?> value="2" onclick="itemclicked('answer14');" ></td>
            <td><input type="radio" name="answer14" <?php if($result['answer14']=="3") echo "checked";?> value="3" onclick="itemclicked('answer14');" ></td>
            <td><input type="radio" name="answer14" <?php if($result['answer14']=="4") echo "checked";?> value="4" onclick="itemclicked('answer14');" ></td>
            <td><input type="radio" name="answer14" <?php if($result['answer14']=="5") echo "checked";?> value="5" onclick="itemclicked('answer14');" ></td>
          </tr>
        </tbody>

        <tbody>
          <tr>
            <td><?=$res15['no_soalan']?></td>
            <td><?=$res15['soalan']?></td>
            <td><input type="radio" name="answer15" <?php if($result['answer15']=="1") echo "checked";?> value="1" onclick="itemclicked('answer15');" ></td>
            <td><input type="radio" name="answer15" <?php if($result['answer15']=="2") echo "checked";?> value="2" onclick="itemclicked('answer15');" ></td>
            <td><input type="radio" name="answer15" <?php if($result['answer15']=="3") echo "checked";?> value="3" onclick="itemclicked('answer15');" ></td>
            <td><input type="radio" name="answer15" <?php if($result['answer15']=="4") echo "checked";?> value="4" onclick="itemclicked('answer15');" ></td>
            <td><input type="radio" name="answer15" <?php if($result['answer15']=="5") echo "checked";?> value="5" onclick="itemclicked('answer15');" ></td>
          </tr>
        </tbody>

        <tbody>
          <tr>
            <td><?=$res16['no_soalan']?></td>
            <td><?=$res16['soalan']?></td>
            <td><input type="radio" name="answer16" <?php if($result['answer16']=="1") echo "checked";?> value="1" onclick="itemclicked('answer16');" ></td>
            <td><input type="radio" name="answer16" <?php if($result['answer16']=="2") echo "checked";?> value="2" onclick="itemclicked('answer16');" ></td>
            <td><input type="radio" name="answer16" <?php if($result['answer16']=="3") echo "checked";?> value="3" onclick="itemclicked('answer16');" ></td>
            <td><input type="radio" name="answer16" <?php if($result['answer16']=="4") echo "checked";?> value="4" onclick="itemclicked('answer16');" ></td>
            <td><input type="radio" name="answer16" <?php if($result['answer16']=="5") echo "checked";?> value="5" onclick="itemclicked('answer16');" ></td>
          </tr>
        </tbody>
      </table>
      <!-- ========================================================================================================================= -->
      
      <table class="table table-hover table table-bordered"
        style="width: 100%;"><h3>Mindfulness</h3>

        <thead class="thead-dark">
          <tr>
            <th scope="col">Ques No.</th>
            <th scope="col">Question</th>
            <th scope="col">Strongly Disagree</th>
            <th scope="col">Disagree</th>
            <th scope="col">Neutral</th>
            <th scope="col">Agree</th>
            <th scope="col">Strongly Agree</th>

          </tr>
        </thead>

        <tbody>
          <tr>
            <td><?=$res17['no_soalan']?></td>
            <td><?=$res17['soalan']?></td>
            <td><input type="radio" name="answer17" <?php if($result['answer17']=="1") echo "checked";?> value="1" onclick="itemclicked('answer17');" ></td>
            <td><input type="radio" name="answer17" <?php if($result['answer17']=="2") echo "checked";?> value="2" onclick="itemclicked('answer17');" ></td>
            <td><input type="radio" name="answer17" <?php if($result['answer17']=="3") echo "checked";?> value="3" onclick="itemclicked('answer17');" ></td>
            <td><input type="radio" name="answer17" <?php if($result['answer17']=="4") echo "checked";?> value="4" onclick="itemclicked('answer17');" ></td>
            <td><input type="radio" name="answer17" <?php if($result['answer17']=="5") echo "checked";?> value="5" onclick="itemclicked('answer17');" ></td>
          </tr>
        </tbody>

        <tbody>
          <tr>
            <td><?=$res18['no_soalan']?></td>
            <td><?=$res18['soalan']?></td>
            <td><input type="radio" name="answer18" <?php if($result['answer18']=="1") echo "checked";?> value="1" onclick="itemclicked('answer18');" ></td>
            <td><input type="radio" name="answer18" <?php if($result['answer18']=="2") echo "checked";?> value="2" onclick="itemclicked('answer18');" ></td>
            <td><input type="radio" name="answer18" <?php if($result['answer18']=="3") echo "checked";?> value="3" onclick="itemclicked('answer18');" ></td>
            <td><input type="radio" name="answer18" <?php if($result['answer18']=="4") echo "checked";?> value="4" onclick="itemclicked('answer18');" ></td>
            <td><input type="radio" name="answer18" <?php if($result['answer18']=="5") echo "checked";?> value="5" onclick="itemclicked('answer18');" ></td>
          </tr>
        </tbody>

        <tbody>
          <tr>
            <td><?=$res19['no_soalan']?></td>
            <td><?=$res19['soalan']?></td>
            <td><input type="radio" name="answer19" <?php if($result['answer19']=="1") echo "checked";?> value="1" onclick="itemclicked('answer19');" ></td>
            <td><input type="radio" name="answer19" <?php if($result['answer19']=="2") echo "checked";?> value="2" onclick="itemclicked('answer19');" ></td>
            <td><input type="radio" name="answer19" <?php if($result['answer19']=="3") echo "checked";?> value="3" onclick="itemclicked('answer19');" ></td>
            <td><input type="radio" name="answer19" <?php if($result['answer19']=="4") echo "checked";?> value="4" onclick="itemclicked('answer19');" ></td>
            <td><input type="radio" name="answer19" <?php if($result['answer19']=="5") echo "checked";?> value="5" onclick="itemclicked('answer19');" ></td>
          </tr>
        </tbody>

        <tbody>
          <tr>
            <td><?=$res20['no_soalan']?></td>
            <td><?=$res20['soalan']?></td>
            <td><input type="radio" name="answer20" <?php if($result['answer20']=="1") echo "checked";?> value="1" onclick="itemclicked('answer20');" ></td>
            <td><input type="radio" name="answer20" <?php if($result['answer20']=="2") echo "checked";?> value="2" onclick="itemclicked('answer20');" ></td>
            <td><input type="radio" name="answer20" <?php if($result['answer20']=="3") echo "checked";?> value="3" onclick="itemclicked('answer20');" ></td>
            <td><input type="radio" name="answer20" <?php if($result['answer20']=="4") echo "checked";?> value="4" onclick="itemclicked('answer20');" ></td>
            <td><input type="radio" name="answer20" <?php if($result['answer20']=="5") echo "checked";?> value="5" onclick="itemclicked('answer20');" ></td>
          </tr>
        </tbody>

        <tbody>
          <tr>
            <td><?=$res21['no_soalan']?></td>
            <td><?=$res21['soalan']?></td>
            <td><input type="radio" name="answer21" <?php if($result['answer21']=="1") echo "checked";?> value="1" onclick="itemclicked('answer21');" ></td>
            <td><input type="radio" name="answer21" <?php if($result['answer21']=="2") echo "checked";?> value="2" onclick="itemclicked('answer21');" ></td>
            <td><input type="radio" name="answer21" <?php if($result['answer21']=="3") echo "checked";?> value="3" onclick="itemclicked('answer21');" ></td>
            <td><input type="radio" name="answer21" <?php if($result['answer21']=="4") echo "checked";?> value="4" onclick="itemclicked('answer21');" ></td>
            <td><input type="radio" name="answer21" <?php if($result['answer21']=="5") echo "checked";?> value="5" onclick="itemclicked('answer21');" ></td>
          </tr>
        </tbody>

        <tbody>
          <tr>
            <td><?=$res22['no_soalan']?></td>
            <td><?=$res22['soalan']?></td>
            <td><input type="radio" name="answer22" <?php if($result['answer22']=="1") echo "checked";?> value="1" onclick="itemclicked('answer22');" ></td>
            <td><input type="radio" name="answer22" <?php if($result['answer22']=="2") echo "checked";?> value="2" onclick="itemclicked('answer22');" ></td>
            <td><input type="radio" name="answer22" <?php if($result['answer22']=="3") echo "checked";?> value="3" onclick="itemclicked('answer22');" ></td>
            <td><input type="radio" name="answer22" <?php if($result['answer22']=="4") echo "checked";?> value="4" onclick="itemclicked('answer22');" ></td>
            <td><input type="radio" name="answer22" <?php if($result['answer22']=="5") echo "checked";?> value="5" onclick="itemclicked('answer22');" ></td>
          </tr>
        </tbody>
      </table>
      <!-- ========================================================================================================================= -->
      
      <table class="table table-hover table table-bordered"
        style="width: 100%;"><h3>Resilience</h3>

        <thead class="thead-dark">
          <tr>
            <th scope="col">Ques No.</th>
            <th scope="col">Question</th>
            <th scope="col">Strongly Disagree</th>
            <th scope="col">Disagree</th>
            <th scope="col">Neutral</th>
            <th scope="col">Agree</th>
            <th scope="col">Strongly Agree</th>
          </tr>
        </thead>
        
        <tbody>
          <tr>
            <td><?=$res23['no_soalan']?></td>
            <td><?=$res23['soalan']?></td>
            <td><input type="radio" name="answer23" <?php if($result['answer23']=="1") echo "checked";?> value="1" onclick="itemclicked('answer23');" ></td>
            <td><input type="radio" name="answer23" <?php if($result['answer23']=="2") echo "checked";?> value="2" onclick="itemclicked('answer23');" ></td>
            <td><input type="radio" name="answer23" <?php if($result['answer23']=="3") echo "checked";?> value="3" onclick="itemclicked('answer23');" ></td>
            <td><input type="radio" name="answer23" <?php if($result['answer23']=="4") echo "checked";?> value="4" onclick="itemclicked('answer23');" ></td>
            <td><input type="radio" name="answer23" <?php if($result['answer23']=="5") echo "checked";?> value="5" onclick="itemclicked('answer23');" ></td>
          </tr>
        </tbody>

        <tbody>
          <tr>
            <td><?=$res24['no_soalan']?></td>
            <td><?=$res24['soalan']?></td>
            <td><input type="radio" name="answer24" <?php if($result['answer24']=="1") echo "checked";?> value="1" onclick="itemclicked('answer24');" ></td>
            <td><input type="radio" name="answer24" <?php if($result['answer24']=="2") echo "checked";?> value="2" onclick="itemclicked('answer24');" ></td>
            <td><input type="radio" name="answer24" <?php if($result['answer24']=="3") echo "checked";?> value="3" onclick="itemclicked('answer24');" ></td>
            <td><input type="radio" name="answer24" <?php if($result['answer24']=="4") echo "checked";?> value="4" onclick="itemclicked('answer24');" ></td>
            <td><input type="radio" name="answer24" <?php if($result['answer24']=="5") echo "checked";?> value="5" onclick="itemclicked('answer24');" ></td>
          </tr>
        </tbody>

        <tbody>
          <tr>
            <td><?=$res25['no_soalan']?></td>
            <td><?=$res25['soalan']?></td>
            <td><input type="radio" name="answer25" <?php if($result['answer25']=="1") echo "checked";?> value="1" onclick="itemclicked('answer25');" ></td>
            <td><input type="radio" name="answer25" <?php if($result['answer25']=="2") echo "checked";?> value="2" onclick="itemclicked('answer25');" ></td>
            <td><input type="radio" name="answer25" <?php if($result['answer25']=="3") echo "checked";?> value="3" onclick="itemclicked('answer25');" ></td>
            <td><input type="radio" name="answer25" <?php if($result['answer25']=="4") echo "checked";?> value="4" onclick="itemclicked('answer25');" ></td>
            <td><input type="radio" name="answer25" <?php if($result['answer25']=="5") echo "checked";?> value="5" onclick="itemclicked('answer25');" ></td>
          </tr>
        </tbody>

        <tbody>
          <tr>
            <td><?=$res26['no_soalan']?></td>
            <td><?=$res26['soalan']?></td>
            <td><input type="radio" name="answer26" <?php if($result['answer26']=="1") echo "checked";?> value="1" onclick="itemclicked('answer26');" ></td>
            <td><input type="radio" name="answer26" <?php if($result['answer26']=="2") echo "checked";?> value="2" onclick="itemclicked('answer26');" ></td>
            <td><input type="radio" name="answer26" <?php if($result['answer26']=="3") echo "checked";?> value="3" onclick="itemclicked('answer26');"></td>
            <td><input type="radio" name="answer26" <?php if($result['answer26']=="4") echo "checked";?> value="4" onclick="itemclicked('answer26');" ></td>
            <td><input type="radio" name="answer26" <?php if($result['answer26']=="5") echo "checked";?> value="5" onclick="itemclicked('answer26');" ></td>
          </tr>
        </tbody>

        <tbody>
          <tr>
            <td><?=$res27['no_soalan']?></td>
            <td><?=$res27['soalan']?></td>
            <td><input type="radio" name="answer27" <?php if($result['answer27']=="1") echo "checked";?> value="1" onclick="itemclicked('answer27');" ></td>
            <td><input type="radio" name="answer27" <?php if($result['answer27']=="2") echo "checked";?> value="2" onclick="itemclicked('answer27');" ></td>
            <td><input type="radio" name="answer27" <?php if($result['answer27']=="3") echo "checked";?> value="3" onclick="itemclicked('answer27');" ></td>
            <td><input type="radio" name="answer27" <?php if($result['answer27']=="4") echo "checked";?> value="4" onclick="itemclicked('answer27');" ></td>
            <td><input type="radio" name="answer27" <?php if($result['answer27']=="5") echo "checked";?> value="5" onclick="itemclicked('answer27');" ></td>
          </tr>
        </tbody>

        <tbody>
          <tr>
            <td><?=$res28['no_soalan']?></td>
            <td><?=$res28['soalan']?></td>
            <td><input type="radio" name="answer28" <?php if($result['answer28']=="1") echo "checked";?> value="1" onclick="itemclicked('answer28');" ></td>
            <td><input type="radio" name="answer28" <?php if($result['answer28']=="2") echo "checked";?> value="2" onclick="itemclicked('answer28');" ></td>
            <td><input type="radio" name="answer28" <?php if($result['answer28']=="3") echo "checked";?> value="3" onclick="itemclicked('answer28');" ></td>
            <td><input type="radio" name="answer28" <?php if($result['answer28']=="4") echo "checked";?> value="4" onclick="itemclicked('answer28');" ></td>
            <td><input type="radio" name="answer28" <?php if($result['answer28']=="5") echo "checked";?> value="5" onclick="itemclicked('answer28');" ></td>
          </tr>
        </tbody>
      </table>

      <!-- ========================================================================================================================= -->
      <table class="table table-hover table table-bordered"
        style="width: 100%;"><h3>Communication</h3>

        <thead class="thead-dark">
          <tr>
            <th scope="col">Ques No.</th>
            <th scope="col">Question</th>
            <th scope="col">Strongly Disagree</th>
            <th scope="col">Disagree</th>
            <th scope="col">Neutral</th>
            <th scope="col">Agree</th>
            <th scope="col">Strongly Agree</th>
          </tr>
        </thead>

        <tbody>
          <tr>
            <td><?=$res29['no_soalan']?></td>
            <td><?=$res29['soalan']?></td>
            <td><input type="radio" name="answer29" <?php if($result['answer29']=="1") echo "checked";?> value="1" onclick="itemclicked('answer29');" ></td>
            <td><input type="radio" name="answer29" <?php if($result['answer29']=="2") echo "checked";?> value="2" onclick="itemclicked('answer29');" ></td>
            <td><input type="radio" name="answer29" <?php if($result['answer29']=="3") echo "checked";?> value="3" onclick="itemclicked('answer29');" ></td>
            <td><input type="radio" name="answer29" <?php if($result['answer29']=="4") echo "checked";?> value="4" onclick="itemclicked('answer29');" ></td>
            <td><input type="radio" name="answer29" <?php if($result['answer29']=="5") echo "checked";?> value="5" onclick="itemclicked('answer29');" ></td>
          </tr>
        </tbody>

        <tbody>
          <tr>
            <td><?=$res30['no_soalan']?></td>
            <td><?=$res30['soalan']?></td>
            <td><input type="radio" name="answer30" <?php if($result['answer30']=="1") echo "checked";?> value="1" onclick="itemclicked('answer30');" ></td>
            <td><input type="radio" name="answer30" <?php if($result['answer30']=="2") echo "checked";?> value="2" onclick="itemclicked('answer30');" ></td>
            <td><input type="radio" name="answer30" <?php if($result['answer30']=="3") echo "checked";?> value="3" onclick="itemclicked('answer30');" ></td>
            <td><input type="radio" name="answer30" <?php if($result['answer30']=="4") echo "checked";?> value="4" onclick="itemclicked('answer30');" ></td>
            <td><input type="radio" name="answer30" <?php if($result['answer30']=="5") echo "checked";?> value="5" onclick="itemclicked('answer30');" ></td>
          </tr>
        </tbody>

        <tbody>
          <tr>
            <td><?=$res31['no_soalan']?></td>
            <td><?=$res31['soalan']?></td>
            <td><input type="radio" name="answer31" <?php if($result['answer31']=="1") echo "checked";?> value="1" onclick="itemclicked('answer31');" ></td>
            <td><input type="radio" name="answer31" <?php if($result['answer31']=="2") echo "checked";?> value="2" onclick="itemclicked('answer31');" ></td>
            <td><input type="radio" name="answer31" <?php if($result['answer31']=="3") echo "checked";?> value="3" onclick="itemclicked('answer31');" ></td>
            <td><input type="radio" name="answer31" <?php if($result['answer31']=="4") echo "checked";?> value="4" onclick="itemclicked('answer31');" ></td>
            <td><input type="radio" name="answer31" <?php if($result['answer31']=="5") echo "checked";?> value="5" onclick="itemclicked('answer31');" ></td>
          </tr>
        </tbody>

        <tbody>
          <tr>
            <td><?=$res32['no_soalan']?></td>
            <td><?=$res32['soalan']?></td>
            <td><input type="radio" name="answer32" <?php if($result['answer32']=="1") echo "checked";?> value="1" onclick="itemclicked('answer32');" ></td>
            <td><input type="radio" name="answer32" <?php if($result['answer32']=="2") echo "checked";?> value="2" onclick="itemclicked('answer32');" ></td>
            <td><input type="radio" name="answer32" <?php if($result['answer32']=="3") echo "checked";?> value="3" onclick="itemclicked('answer32');" ></td>
            <td><input type="radio" name="answer32" <?php if($result['answer32']=="4") echo "checked";?> value="4" onclick="itemclicked('answer32');" ></td>
            <td><input type="radio" name="answer32" <?php if($result['answer32']=="5") echo "checked";?> value="5" onclick="itemclicked('answer32');" ></td>
          </tr>
        </tbody>
        
        <tbody>
          <tr>
            <td><?=$res33['no_soalan']?></td>
            <td><?=$res33['soalan']?></td>
            <td><input type="radio" name="answer33" <?php if($result['answer33']=="1") echo "checked";?> value="1" onclick="itemclicked('answer33');" ></td>
            <td><input type="radio" name="answer33" <?php if($result['answer33']=="2") echo "checked";?> value="2" onclick="itemclicked('answer33');" ></td>
            <td><input type="radio" name="answer33" <?php if($result['answer33']=="3") echo "checked";?> value="3" onclick="itemclicked('answer33');" ></td>
            <td><input type="radio" name="answer33" <?php if($result['answer33']=="4") echo "checked";?> value="4" onclick="itemclicked('answer33');" ></td>
            <td><input type="radio" name="answer33" <?php if($result['answer33']=="5") echo "checked";?> value="5" onclick="itemclicked('answer33');" ></td>
          </tr>
        </tbody>

        <tbody>
          <tr>
            <td><?=$res34['no_soalan']?></td>
            <td><?=$res34['soalan']?></td>
            <td><input type="radio" name="answer34" <?php if($result['answer34']=="1") echo "checked";?> value="1" onclick="itemclicked('answer34');" ></td>
            <td><input type="radio" name="answer34" <?php if($result['answer34']=="2") echo "checked";?> value="2" onclick="itemclicked('answer34');" ></td>
            <td><input type="radio" name="answer34" <?php if($result['answer34']=="3") echo "checked";?> value="3" onclick="itemclicked('answer34');" ></td>
            <td><input type="radio" name="answer34" <?php if($result['answer34']=="4") echo "checked";?> value="4" onclick="itemclicked('answer34');" ></td>
            <td><input type="radio" name="answer34" <?php if($result['answer34']=="5") echo "checked";?> value="5" onclick="itemclicked('answer34');" ></td>
          </tr>
        </tbody>
      </table>

      <!-- ========================================================================================================================= -->
      <table class="table table-hover table table-bordered"
        style="width: 100%;"><h3>Teamwork</h3>

        <thead class="thead-dark">
          <tr>
            <th scope="col">Ques No.</th>
            <th scope="col">Question</th>
            <th scope="col">Strongly Disagree</th>
            <th scope="col">Disagree</th>
            <th scope="col">Neutral</th>
            <th scope="col">Agree</th>
            <th scope="col">Strongly Agree</th>
          </tr>
        </thead>

        <tbody>
          <tr>
            <td><?=$res35['no_soalan']?></td>
            <td><?=$res35['soalan']?></td>
            <td><input type="radio" name="answer35" <?php if($result['answer35']=="1") echo "checked";?> value="1" onclick="itemclicked('answer35');" ></td>
            <td><input type="radio" name="answer35" <?php if($result['answer35']=="2") echo "checked";?> value="2" onclick="itemclicked('answer35');" ></td>
            <td><input type="radio" name="answer35" <?php if($result['answer35']=="3") echo "checked";?> value="3" onclick="itemclicked('answer35');" ></td>
            <td><input type="radio" name="answer35" <?php if($result['answer35']=="4") echo "checked";?> value="4" onclick="itemclicked('answer35');" ></td>
            <td><input type="radio" name="answer35" <?php if($result['answer35']=="5") echo "checked";?> value="5" onclick="itemclicked('answer35');" ></td>
          </tr>
        </tbody>

        <tbody>
          <tr>
            <td><?=$res36['no_soalan']?></td>
            <td><?=$res36['soalan']?></td>
            <td><input type="radio" name="answer36" <?php if($result['answer36']=="1") echo "checked";?> value="1" onclick="itemclicked('answer36');" ></td>
            <td><input type="radio" name="answer36" <?php if($result['answer36']=="2") echo "checked";?> value="2" onclick="itemclicked('answer36');" ></td>
            <td><input type="radio" name="answer36" <?php if($result['answer36']=="3") echo "checked";?> value="3" onclick="itemclicked('answer36');" ></td>
            <td><input type="radio" name="answer36" <?php if($result['answer36']=="4") echo "checked";?> value="4" onclick="itemclicked('answer36');" ></td>
            <td><input type="radio" name="answer36" <?php if($result['answer36']=="5") echo "checked";?> value="5" onclick="itemclicked('answer36');" ></td>
          </tr>
        </tbody>

        <tbody>
          <tr>
            <td><?=$res37['no_soalan']?></td>
            <td><?=$res37['soalan']?></td>
            <td><input type="radio" name="answer37" <?php if($result['answer37']=="1") echo "checked";?> value="1" onclick="itemclicked('answer37');" ></td>
            <td><input type="radio" name="answer37" <?php if($result['answer37']=="2") echo "checked";?> value="2" onclick="itemclicked('answer37');"></td>
            <td><input type="radio" name="answer37" <?php if($result['answer37']=="3") echo "checked";?> value="3" onclick="itemclicked('answer37');" ></td>
            <td><input type="radio" name="answer37" <?php if($result['answer37']=="4") echo "checked";?> value="4" onclick="itemclicked('answer37');" ></td>
            <td><input type="radio" name="answer37" <?php if($result['answer37']=="5") echo "checked";?> value="5" onclick="itemclicked('answer37');" ></td>
          </tr>
        </tbody>

        <tbody>
          <tr>
            <td><?=$res38['no_soalan']?></td>
            <td><?=$res38['soalan']?></td>
            <td><input type="radio" name="answer38" <?php if($result['answer38']=="1") echo "checked";?> value="1" onclick="itemclicked('answer38');" ></td>
            <td><input type="radio" name="answer38" <?php if($result['answer38']=="2") echo "checked";?> value="2" onclick="itemclicked('answer38');" ></td>
            <td><input type="radio" name="answer38" <?php if($result['answer38']=="3") echo "checked";?> value="3" onclick="itemclicked('answer38');" ></td>
            <td><input type="radio" name="answer38" <?php if($result['answer38']=="4") echo "checked";?> value="4" onclick="itemclicked('answer38');" ></td>
            <td><input type="radio" name="answer38" <?php if($result['answer38']=="5") echo "checked";?> value="5" onclick="itemclicked('answer38');" ></td>
          </tr>
        </tbody>

        <tbody>
          <tr>
            <td><?=$res39['no_soalan']?></td>
            <td><?=$res39['soalan']?></td>
            <td><input type="radio" name="answer39" <?php if($result['answer39']=="1") echo "checked";?> value="1" onclick="itemclicked('answer39');" ></td>
            <td><input type="radio" name="answer39" <?php if($result['answer39']=="2") echo "checked";?> value="2" onclick="itemclicked('answer39');" ></td>
            <td><input type="radio" name="answer39" <?php if($result['answer39']=="3") echo "checked";?> value="3" onclick="itemclicked('answer39');" ></td>
            <td><input type="radio" name="answer39" <?php if($result['answer39']=="4") echo "checked";?> value="4" onclick="itemclicked('answer39');" ></td>
            <td><input type="radio" name="answer39" <?php if($result['answer39']=="5") echo "checked";?> value="5" onclick="itemclicked('answer39');" ></td>
          </tr>
        </tbody>

        <tbody>
          <tr>
            <td><?=$res40['no_soalan']?></td>
            <td><?=$res40['soalan']?></td>
            <td><input type="radio" name="answer40" <?php if($result['answer40']=="1") echo "checked";?> value="1" onclick="itemclicked('answer40');" ></td>
            <td><input type="radio" name="answer40" <?php if($result['answer40']=="2") echo "checked";?> value="2" onclick="itemclicked('answer40');" ></td>
            <td><input type="radio" name="answer40" <?php if($result['answer40']=="3") echo "checked";?> value="3" onclick="itemclicked('answer40');" ></td>
            <td><input type="radio" name="answer40" <?php if($result['answer40']=="4") echo "checked";?> value="4" onclick="itemclicked('answer40');" ></td>
            <td><input type="radio" name="answer40" <?php if($result['answer40']=="5") echo "checked";?> value="5" onclick="itemclicked('answer40');" ></td>
          </tr>
        </tbody>

      </table>

      <!-- ======================================================================================================================== -->
      <table class="table table-hover table table-bordered"
        style="width: 100%;"><h3>Creativity</h3>

        <thead class="thead-dark">
          <tr>
            <th scope="col">Ques No.</th>
            <th scope="col">Question</th>
            <th scope="col">Strongly Disagree</th>
            <th scope="col">Disagree</th>
            <th scope="col">Neutral</th>
            <th scope="col">Agree</th>
            <th scope="col">Strongly Agree</th>
          </tr>
        </thead>

        <tbody>
          <tr>
            <td><?=$res42['no_soalan']?></td>
            <td><?=$res42['soalan']?></td>
            <td><input type="radio" name="answer41" <?php if($result['answer41']=="1") echo "checked";?> value="1" onclick="itemclicked('answer42');" ></td>
            <td><input type="radio" name="answer41" <?php if($result['answer41']=="2") echo "checked";?> value="2" onclick="itemclicked('answer41');" ></td>
            <td><input type="radio" name="answer41" <?php if($result['answer41']=="3") echo "checked";?> value="3" onclick="itemclicked('answer41');" ></td>
            <td><input type="radio" name="answer41" <?php if($result['answer41']=="4") echo "checked";?> value="4" onclick="itemclicked('answer41');" ></td>
            <td><input type="radio" name="answer41" <?php if($result['answer41']=="5") echo "checked";?> value="5" onclick="itemclicked('answer41');" ></td>
          </tr>
        </tbody>

        <tbody>
          <tr>
            <td><?=$res42['no_soalan']?></td>
            <td><?=$res42['soalan']?></td>
            <td><input type="radio" name="answer42" <?php if($result['answer42']=="1") echo "checked";?> value="1" onclick="itemclicked('answer42');" ></td>
            <td><input type="radio" name="answer42" <?php if($result['answer42']=="2") echo "checked";?> value="2" onclick="itemclicked('answer42');" ></td>
            <td><input type="radio" name="answer42" <?php if($result['answer42']=="3") echo "checked";?> value="3" onclick="itemclicked('answer42');" ></td>
            <td><input type="radio" name="answer42" <?php if($result['answer42']=="4") echo "checked";?> value="4" onclick="itemclicked('answer42');" ></td>
            <td><input type="radio" name="answer42" <?php if($result['answer42']=="5") echo "checked";?> value="5" onclick="itemclicked('answer42');" ></td>
          </tr>
        </tbody>

        <tbody>
          <tr>
            <td><?=$res43['no_soalan']?></td>
            <td><?=$res43['soalan']?></td>
            <td><input type="radio" name="answer43" <?php if($result['answer43']=="1") echo "checked";?> value="1" onclick="itemclicked('answer43');" ></td>
            <td><input type="radio" name="answer43" <?php if($result['answer43']=="2") echo "checked";?> value="2" onclick="itemclicked('answer43');" ></td>
            <td><input type="radio" name="answer43" <?php if($result['answer43']=="3") echo "checked";?> value="3" onclick="itemclicked('answer43');" ></td>
            <td><input type="radio" name="answer43" <?php if($result['answer43']=="4") echo "checked";?> value="4" onclick="itemclicked('answer43');" ></td>
            <td><input type="radio" name="answer43" <?php if($result['answer43']=="5") echo "checked";?> value="5" onclick="itemclicked('answer43');" ></td>
          </tr>
        </tbody>

        <tbody>
          <tr>
            <td><?=$res44['no_soalan']?></td>
            <td><?=$res44['soalan']?></td>
            <td><input type="radio" name="answer44" <?php if($result['answer44']=="1") echo "checked";?> value="1" onclick="itemclicked('answer44');" ></td>
            <td><input type="radio" name="answer44" <?php if($result['answer44']=="2") echo "checked";?> value="2" onclick="itemclicked('answer44');" ></td>
            <td><input type="radio" name="answer44" <?php if($result['answer44']=="3") echo "checked";?> value="3" onclick="itemclicked('answer44');" ></td>
            <td><input type="radio" name="answer44" <?php if($result['answer44']=="4") echo "checked";?> value="4" onclick="itemclicked('answer44');" ></td>
            <td><input type="radio" name="answer44" <?php if($result['answer44']=="5") echo "checked";?> value="5" onclick="itemclicked('answer44');" ></td>
          </tr>
        </tbody>

        <tbody>
          <tr>
            <td><?=$res45['no_soalan']?></td>
            <td><?=$res45['soalan']?></td>
            <td><input type="radio" name="answer45" <?php if($result['answer45']=="1") echo "checked";?> value="1" onclick="itemclicked('answer45');" ></td>
            <td><input type="radio" name="answer45" <?php if($result['answer45']=="2") echo "checked";?> value="2" onclick="itemclicked('answer45');" ></td>
            <td><input type="radio" name="answer45" <?php if($result['answer45']=="3") echo "checked";?> value="3" onclick="itemclicked('answer45');" ></td>
            <td><input type="radio" name="answer45" <?php if($result['answer45']=="4") echo "checked";?> value="4" onclick="itemclicked('answer45');" ></td>
            <td><input type="radio" name="answer45" <?php if($result['answer45']=="5") echo "checked";?> value="5" onclick="itemclicked('answer45');" ></td>
          </tr>
        </tbody>

      </table>

      <div>
        <button type="submit" id="submit" name ="submit">Submit</button>    <!-- onclick="DisableButton(this);" -->
        <input type="submit" name="save" value="Save"/>
        <input type="reset"/>
      </div>
    <!-- </div> -->
    <?php
    $i++;
      // }
    ?>
  </table>

</form>

</div>

</section>

<?php include("includes/footer.php"); ?>

</body>
</html>

<?php
// include "db_conn.php";

if(isset($_POST['submit'])) {

  $answer1=$_POST['answer1']; //INTEGRITY
  $answer2=$_POST['answer2'];
  $answer3=$_POST['answer3'];
  $answer4=$_POST['answer4'];
  $answer5=$_POST['answer5'];

  $answer6=$_POST['answer6']; //EMOTIONAL INTELLIGENCE
  $answer7=$_POST['answer7'];
  $answer8=$_POST['answer8'];
  $answer9=$_POST['answer9'];
  $answer10=$_POST['answer10']; 
  $answer11=$_POST['answer11'];

  $answer12=$_POST['answer12']; //ADAPTABILITY
  $answer13=$_POST['answer13'];
  $answer14=$_POST['answer14'];
  $answer15=$_POST['answer15'];
  $answer16=$_POST['answer16'];

  $answer17=$_POST['answer17']; //MINDFULNESS
  $answer18=$_POST['answer18'];
  $answer19=$_POST['answer19'];
  $answer20=$_POST['answer20'];
  $answer21=$_POST['answer21'];
  $answer22=$_POST['answer22'];

  $answer23=$_POST['answer23']; //RESILIENCE
  $answer24=$_POST['answer24'];
  $answer25=$_POST['answer25'];
  $answer26=$_POST['answer26'];
  $answer27=$_POST['answer27'];
  $answer28=$_POST['answer28'];

  $answer29=$_POST['answer29']; //COMMUNICATION
  $answer30=$_POST['answer30'];
  $answer31=$_POST['answer31'];
  $answer32=$_POST['answer32'];
  $answer33=$_POST['answer33'];
  $answer34=$_POST['answer34'];

  $answer35=$_POST['answer35']; //TEAMWORK
  $answer36=$_POST['answer36'];
  $answer37=$_POST['answer37'];
  $answer38=$_POST['answer38'];
  $answer39=$_POST['answer39'];
  $answer40=$_POST['answer40'];

  $answer41=$_POST['answer41']; //CREATIVITY
  $answer42=$_POST['answer42'];
  $answer43=$_POST['answer43'];
  $answer44=$_POST['answer44'];
  $answer45=$_POST['answer45'];

  $matric=(int)$_POST['matric'];
  // =================================================================================================================
  $total=$answer1+$answer2+$answer3+$answer4+$answer5; //INTEGRITY
  $average=$total/5;
  if($average>5.00){
    $integrity='Your score is at the top 10 percent of the student population. It seems that you don’t have to worry much about your present level of INTEGRITY. Please put efforts to improve lower-rated readiness dimension, if applicable.';
  }else if($average>4.20&&$average<=5.00){
    $integrity='Your score, while not too high, is in the upper half of the student population. You may work on INTEGRITY after paying attention to lower-rated readiness dimension where applicable.';
  }else if($average>4.00&&$average<=4.20){
    $integrity='You score is about average. This is not a cause for concern, but you should consider improving your INTEGRITY ';
  }else if($average>3.40&&$average<=4.00){
    $integrity='Your score, while not too low, is in the lower half of the student population. This is an area in which you can put efforts to improve.';
  }else{
    $integrity='Your score is in the bottom 10 percent of the student population; 90% of students have higher scores. It seems that you should make improving INTEGRITY a priority.';
  }
  // =======================================================================================================================
  $total2=$answer6+$answer7+$answer8+$answer9+$answer10+$answer11; //EMOTIONAL INTELLIGENCE
  $average2=$total2/6;
  if($average2>4.67){
    $emotional='Your score is at the top 10 percent of the student population. It seems that you don’t have to worry much about your present level of EMOTIONAL INTELLIGENCE. Please put efforts to improve lower-rated readiness dimension, if applicable.';
  }else if($average2>4.00&&$average2<=4.67){
    $emotional='Your score, while not too high, is in the upper half of the student population. You may work on EMOTIONAL INTELLIGENCE after paying attention to lower-rated readiness dimension where applicable.';
  }else if($average2>3.67&&$average2<=4.00){
    $emotional='You score is about average. This is not a cause for concern, but you should consider improving your EMOTIONAL INTELLIGENCE ';
  }else if($average2>3.00&&$average2<=3.67){
    $emotional='Your score, while not too low, is in the lower half of the student population. This is an area in which you can put efforts to improve.';
  }else{
    $emotional='Your score is in the bottom 10 percent of the student population; 90% of students have higher scores. It seems that you should make improving EMOTIONAL INTELLIGENCE a priority.';
  }
  // ==========================================================================================================================
  $total3=$answer12+$answer13+$answer14+$answer15+$answer16; //ADAPTABILTY
  $average3=$total3/5;
  if($average3>5.00){
    $adapt='Your score is at the top 10 percent of the student population. It seems that you don’t have to worry much about your present level of ADAPTABILITY. Please put efforts to improve lower-rated readiness dimension, if applicable.';
  }else if($average3>4.20&&$average3<=5.00){
    $adapt='Your score, while not too high, is in the upper half of the student population. You may work on ADAPTABILITY after paying attention to lower-rated readiness dimension where applicable.';
  }else if($average3>4.00&&$average3<=4.20){
    $adapt='You score is about average. This is not a cause for concern, but you should consider improving your ADAPTABILITY ';
  }else if($average3>3.20&&$average3<=4.00){
    $adapt='Your score, while not too low, is in the lower half of the student population. This is an area in which you can put efforts to improve.';
  }else{
    $adapt='Your score is in the bottom 10 percent of the student population; 90% of students have higher scores. It seems that you should make improving ADAPTABILITY a priority.';
  }
  // =========================================================================================================================

  $total4=$answer17+$answer18+$answer19+$answer20+$answer21+$answer22; //MINDFULNESS
  $average4=$total4/6;
  if($average4>5.00){
    $mind='Your score is at the top 10 percent of the student population. It seems that you don’t have to worry much about your present level of MINDFULNESS. Please put efforts to improve lower-rated readiness dimension, if applicable.';
  }else if($average4>4.17&&$average4<=5.00){
    $mind='Your score, while not too high, is in the upper half of the student population. You may work on MINDFULNESS after paying attention to lower-rated readiness dimension where applicable.';
  }else if($average4>3.83&&$average4<=4.17){
    $mind='You score is about average. This is not a cause for concern, but you should consider improving your MINDFULNESS ';
  }else if($average4>3.00&&$average4<=3.83){
    $mind='Your score, while not too low, is in the lower half of the student population. This is an area in which you can put efforts to improve.';
  }else{
    $mind='Your score is in the bottom 10 percent of the student population; 90% of students have higher scores. It seems that you should make improving MINDFULNESS a priority.';
  }
  // ============================================================================================================================

  $total5=$answer23+$answer24+$answer25+$answer26+$answer27+$answer28; //RESILIENCE
  $average5=$total5/6;
  if($average5>4.68){
    $resil='Your score is at the top 10 percent of the student population. It seems that you don’t have to worry much about your present level of RESILIENCE. Please put efforts to improve lower-rated readiness dimension, if applicable.';
  }else if($average5>4.00&&$average5<=4.68){
    $resil='Your score, while not too high, is in the upper half of the student population. You may work on RESILIENCE after paying attention to lower-rated readiness dimension where applicable.';
  }else if($average5>3.50&&$average5<=4.00){
    $resil='You score is about average. This is not a cause for concern, but you should consider improving your RESILIENCE ';
  }else if($average5>2.67&&$average5<=3.50){
    $resil='Your score, while not too low, is in the lower half of the student population. This is an area in which you can put efforts to improve.';
  }else{
    $resil='Your score is in the bottom 10 percent of the student population; 90% of students have higher scores. It seems that you should make improving RESILIENCE a priority.';
  }
  // ==========================================================================================================================

  $total6=$answer29+$answer30+$answer31+$answer32+$answer33+$answer34; //COMMUNICATION
  $average6=$total6/6;
  if($average6>5.00){
    $communi='Your score is at the top 10 percent of the student population. It seems that you don’t have to worry much about your present level of COMMUNICATION. Please put efforts to improve lower-rated readiness dimension, if applicable.';
  }else if($average6>4.17&&$average6<=5.00){
    $communi='Your score, while not too high, is in the upper half of the student population. You may work on COMMUNICATION after paying attention to lower-rated readiness dimension where applicable.';
  }else if($average6>3.83&&$average6<=4.17){
    $communi='You score is about average. This is not a cause for concern, but you should consider improving your COMMUNICATION ';
  }else if($average6>3.00&&$average6<=3.83){
    $communi='Your score, while not too low, is in the lower half of the student population. This is an area in which you can put efforts to improve.';
  }else{
    $communi='Your score is in the bottom 10 percent of the student population; 90% of students have higher scores. It seems that you should make improving COMMUNICATION a priority.';
  }
  // ==========================================================================================================================

  $total7=$answer35+$answer36+$answer37+$answer38+$answer39+$answer40; //TEAMWORK
  $average7=$total7/6;
  if($average7>5.00){
    $team='Your score is at the top 10 percent of the student population. It seems that you don’t have to worry much about your present level of TEAMWORK. Please put efforts to improve lower-rated readiness dimension, if applicable.';
  }else if($average7>4.33&&$average7<=5.00){
    $team='Your score, while not too high, is in the upper half of the student population. You may work on TEAMWORK after paying attention to lower-rated readiness dimension where applicable.';
  }else if($average7>4.00&&$average7<=4.33){
    $team='You score is about average. This is not a cause for concern, but you should consider improving your TEAMWORK ';
  }else if($average7>3.17&&$average7<=4.00){
    $team='Your score, while not too low, is in the lower half of the student population. This is an area in which you can put efforts to improve.';
  }else{
    $team='Your score is in the bottom 10 percent of the student population; 90% of students have higher scores. It seems that you should make improving TEAMWORK a priority.';
  }
  // ==========================================================================================================================

  $total8=$answer41+$answer42+$answer43+$answer44+$answer45; //CREATIVITY
  $average8=$total8/5;
  if($average8>5.00){
    $creative='Your score is at the top 10 percent of the student population. It seems that you don’t have to worry much about your present level of CREATIVITY. Please put efforts to improve lower-rated readiness dimension, if applicable.';
  }else if($average8>4.17&&$average8<=5.00){
    $creative='Your score, while not too high, is in the upper half of the student population. You may work on CREATIVITY after paying attention to lower-rated readiness dimension where applicable.';
  }else if($average8>3.83&&$average8<=4.17){
    $creative='You score is about average. This is not a cause for concern, but you should consider improving your CREATIVITY ';
  }else if($average8>3.00&&$average8<=3.83){
    $creative='Your score, while not too low, is in the lower half of the student population. This is an area in which you can put efforts to improve.';
  }else{
    $creative='Your score is in the bottom 10 percent of the student population; 90% of students have higher scores. It seems that you should make improving CREATIVITY a priority.';
  }
  // ==========================================================================================================================
  
  $query1="UPDATE answer SET answer1='$_POST[answer1]', answer2='$_POST[answer2]', answer3='$_POST[answer3]', answer4='$_POST[answer4]', answer5='$_POST[answer5]', answer6='$_POST[answer6]', answer7='$_POST[answer7]', answer8='$_POST[answer8]', answer9='$_POST[answer9]', answer10='$_POST[answer10]',answer11='$_POST[answer11]',answer12='$_POST[answer12]',answer13='$_POST[answer13]',answer14='$_POST[answer14]',answer15='$_POST[answer15]',answer16='$_POST[answer16]',answer17='$_POST[answer17]',answer18='$_POST[answer18]',answer19='$_POST[answer19]',answer20='$_POST[answer20]',answer21='$_POST[answer21]',answer22='$_POST[answer22]',answer23='$_POST[answer23]',answer24='$_POST[answer24]',answer25='$_POST[answer25]',answer26='$_POST[answer26]',answer27='$_POST[answer27]',answer28='$_POST[answer28]', answer29='$_POST[answer29]',answer30='$_POST[answer30]',answer31='$_POST[answer31]',answer32='$_POST[answer32]',answer33='$_POST[answer33]',answer34='$_POST[answer34]',answer35='$_POST[answer35]',answer36='$_POST[answer36]',answer37='$_POST[answer37]',answer38='$_POST[answer38]',answer39='$_POST[answer39]',answer40='$_POST[answer40]',answer41='$_POST[answer41]',answer42='$_POST[answer42]',answer43='$_POST[answer43]',answer44='$_POST[answer44]',answer45='$_POST[answer45]',total='$total',average='$average',integrity='$integrity', total2='$total2',average2='$average2',emotional='$emotional',total3='$total3',average3='$average3',adapt='$adapt',total4='$total4',average4='$average4',mind='$mind',total5='$total5',average5='$average5',resil='$resil',total6='$total6',average6='$average6',communi='$communi',total7='$total7',average7='$average7',team='$team',total8='$total8',average8='$average8',creative='$creative' where matric='$_POST[matric]' ";
  $query_run1=mysqli_query($conn,$query1);

  if($query_run1){
    echo '<script type="text/javascript"> alert("You already submitted your answer! You will be directed to your report") </script>';
    echo'<script> window.location="result.php"; </script> ';
    exit;

  }
}
else if(isset($_POST['save']))
{

  function test_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
  }

  $answer1=$_POST['answer1']; //INTEGRITY
  $answer2=$_POST['answer2'];
  $answer3=$_POST['answer3'];
  $answer4=$_POST['answer4'];
  $answer5=$_POST['answer5'];

  $answer6=$_POST['answer6']; //EMOTIONAL INTELLIGENCE
  $answer7=$_POST['answer7'];
  $answer8=$_POST['answer8'];
  $answer9=$_POST['answer9'];
  $answer10=$_POST['answer10']; 
  $answer11=$_POST['answer11'];

  $answer12=$_POST['answer12']; //ADAPTABILITY
  $answer13=$_POST['answer13'];
  $answer14=$_POST['answer14'];
  $answer15=$_POST['answer15'];
  $answer16=$_POST['answer16'];

  $answer17=$_POST['answer17']; //MINDFULNESS
  $answer18=$_POST['answer18'];
  $answer19=$_POST['answer19'];
  $answer20=$_POST['answer20'];
  $answer21=$_POST['answer21'];
  $answer22=$_POST['answer22'];

  $answer23=$_POST['answer23']; //RESILIENCE
  $answer24=$_POST['answer24'];
  $answer25=$_POST['answer25'];
  $answer26=$_POST['answer26'];
  $answer27=$_POST['answer27'];
  $answer28=$_POST['answer28'];

  $answer29=$_POST['answer29']; //COMMUNICATION
  $answer30=$_POST['answer30'];
  $answer31=$_POST['answer31'];
  $answer32=$_POST['answer32'];
  $answer33=$_POST['answer33'];
  $answer34=$_POST['answer34'];

  $answer35=$_POST['answer35']; //TEAMWORK
  $answer36=$_POST['answer36'];
  $answer37=$_POST['answer37'];
  $answer38=$_POST['answer38'];
  $answer39=$_POST['answer39'];
  $answer40=$_POST['answer40'];

  $answer41=$_POST['answer41']; //CREATIVITY
  $answer42=$_POST['answer42'];
  $answer43=$_POST['answer43'];
  $answer44=$_POST['answer44'];
  $answer45=$_POST['answer45'];

  $matric=(int)$_POST['matric'];

  $query="UPDATE answer SET answer1='$_POST[answer1]', answer2='$_POST[answer2]', answer3='$_POST[answer3]', answer4='$_POST[answer4]', answer5='$_POST[answer5]', answer6='$_POST[answer6]', answer7='$_POST[answer7]', answer8='$_POST[answer8]', answer9='$_POST[answer9]', answer10='$_POST[answer10]',answer11='$_POST[answer11]',answer12='$_POST[answer12]',answer13='$_POST[answer13]',answer14='$_POST[answer14]',answer15='$_POST[answer15]',answer16='$_POST[answer16]',answer17='$_POST[answer17]',answer18='$_POST[answer18]',answer19='$_POST[answer19]',answer20='$_POST[answer20]',answer21='$_POST[answer21]',answer22='$_POST[answer22]',answer23='$_POST[answer23]',answer24='$_POST[answer24]',answer25='$_POST[answer25]',answer26='$_POST[answer26]',answer27='$_POST[answer27]',answer28='$_POST[answer28]', answer29='$_POST[answer29]',answer30='$_POST[answer30]',answer31='$_POST[answer31]',answer32='$_POST[answer32]',answer33='$_POST[answer33]',answer34='$_POST[answer34]',answer35='$_POST[answer35]',answer36='$_POST[answer36]',answer37='$_POST[answer37]',answer38='$_POST[answer38]',answer39='$_POST[answer39]',answer40='$_POST[answer40]',answer41='$_POST[answer41]',answer42='$_POST[answer42]',answer43='$_POST[answer43]',answer44='$_POST[answer44]',answer45='$_POST[answer45]' where matric='$_POST[matric]' ";
  $query_run=mysqli_query($conn,$query);

  if($query_run)
  {
    echo '<script type="text/javascript">alert("Data Saved!") </script>';
    echo'<script> window.location="test.php"; </script> ';
    exit;

  }
  else
  {
    echo '<script type="text/javascript"> alert("Data Not Saved")</script>';
      // header("Location: test.php");
  }

  // }

}

?>


<?php }else{
  header("Location: index.php");
} ?>