<?php
session_start();
include "db_conn.php";
if(isset($_SESSION['username']) && isset($_SESSION['role'])) {  ?>

  <!DOCTYPE html>
  <html>
  <head>

    <title>psychometric-system</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">
    <script type="text/javascript" src="test.js"></script>

    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">

    <title>Psychometric - Index</title>
    <meta content="" name="description">
    <meta content="" name="keywords">

    <!-- Favicons -->
    <link href="assets/img/favicon.png" rel="icon">
    <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

    <!-- Vendor CSS Files -->
    <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
    <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
    <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
    <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

    <!-- Template Main CSS File -->
    <link href="assets/css/style.css" rel="stylesheet">

  </head>
  <body>

    <header id="header" class="fixed-top d-flex align-items-center">
      <div class="container d-flex align-items-center">

        <div class="logo me-auto">
          <h1><a href="test.php">University Malaya</a></h1>
          <!-- Uncomment below if you prefer to use an image logo -->
          <!-- <a href="index.html"><img src="assets/img/logo.png" alt="" class="img-fluid"></a>-->
        </div>

        <nav id="navbar" class="navbar order-last order-lg-0">
          <ul>
            <li><a class="nav-link scrollto" href="adminhome.php">Home</a></li>
            <li><a class="nav-link scrollto" href="adminprofile.php">Student</a></li>
            <li class="dropdown"><a class="nav-link scrollto" href="#"><span>Manage Test</span><i class="bi bi-chevron-down"></i></a>
              <ul>
                <li><a href="addQuestion.php">Add Question</a></li>
                <li><a href="editQuestion.php">Edit Question</a></li>
              </ul>
            </li>
            <li><a class="nav-link scrollto" href="logout.php">Logout</a></li>
          </ul>
          <i class="bi bi-list mobile-nav-toggle"></i>
        </nav><!-- .navbar -->

      </div>
    </header>  

    <div class="container d-flex justify-content-center align-items-center"
    style="min-height: 125vh; background-color: LightGray;">
    <?php if($_SESSION['role'] == 'admin') {?>
      <!-- for admin -->
      
      <form class="border shadow p-3 rounded" style=" background-color: LightGray;" action="" method="POST">
        <h3>Add Question</h3> 

        <form role="form">
          <!-- <div class="form-group">
            <label >Question No</label>

            <input type="text" name="no_soalan" class="form-control" id="no_soalan" required autofocus>
          </div> -->

          <div class="form-group">
            <label class="form-label">Category</label>
          </div>
          <select class="form-select mb-3"
                  name="category"
                  id="category" 
                  aria-label="Default select example">
            <option selected value="integrity">Integrity</option>
            <option value="emotional">Emotional</option>
            <option value="adaptability">Adaptability</option>
            <option value="resilience">Resilience</option>
            <option value="creativity">Creativity</option>
            <option value="teamwork">Teamwork</option>
            <option value="communication">Communication</option>
            <option value="mindfulness">Mindfulness</option>
          </select>

          <div class="form-group">
            <label >Enter Question </label>

            <textarea rows="5" cols="75" class="form-control" name="soalan" id="questionInput" placeholder="Question" required></textarea>
          </div>

          <div class="form-group">
            <label >Option A </label>

            <input type="text" name="optionA" class="form-control" id="optionA" placeholder="Option A" required>
          </div>

          <div class="form-group">
            <label >Option B </label>

            <input type="text" name="optionB" class="form-control" id="optionB" placeholder="Option B" required>
          </div>


          <div class="form-group">
            <label >Option C </label>

            <input type="text" name="optionC" class="form-control" id="optionC" placeholder="Option C" required>

          </div>

          <div class="form-group">
            <label>Option D </label>

            <input type="text" name="optionD" class="form-control" id="optionD" placeholder="Option D" required>
          </div>

          <div class="form-group">
            <label>Option E </label>

            <input type="text" name="optionE" class="form-control" id="optionE" placeholder="Option E" required>
          </div>


          <button type="submit" name="btn" class="btn btn-default">Add Question</button>
          <button type="reset" class="btn btn-default">Reset</button>
        </div>

      </form>
    </form>
  </div>
<?php } ?>

</body>
</html>

<?php }else{
  header("Location: index.php");
} 
?>

<?php
if(isset($_POST['btn']))
{
  $category=$_POST['category'];
  $soalan=$_POST['soalan'];
  $optionA=$_POST['optionA'];
  $optionB=$_POST['optionB'];
  $optionC=$_POST['optionC'];
  $optionD=$_POST['optionD'];    
  $optionE=$_POST['optionE'];


  $sql="insert into soalan(category,soalan,optionA,optionB,optionC,optionD,optionE)
  values('$category','$soalan','$optionA','$optionB','$optionC','$optionD','$optionE')";
  if($conn->query($sql)==TRUE)
  {
    echo '<script type="text/javascript"> alert("Record inserted successfully.") </script>';?>
    
    <!--<script>window.location='viewuser.php';</script>-->
    <?php
  }else
  {
    echo '<script type="text/javascript"> alert("Duplicate question number! Please try again.") </script>';
  }

}
?>