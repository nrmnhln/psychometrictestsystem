<?php
session_start();
include "db_conn.php";
if(!isset($_SESSION['username']) && !isset($_SESSION['id'])) {  ?>

  <!DOCTYPE html>
  <html>

  <?php include("includes/head.php"); ?>
  
  <body>
    
    <!-- ======= Header ======= -->
  <header id="header" class="fixed-top d-flex align-items-center">
    <div class="container d-flex align-items-center">

      <div class="logo me-auto">
        <h1><a href="test.php">University Malaya</a></h1>
        <!-- Uncomment below if you prefer to use an image logo -->
        <!-- <a href="index.html"><img src="assets/img/logo.png" alt="" class="img-fluid"></a>-->
      </div>

      <nav id="navbar" class="navbar order-last order-lg-0">
        <ul>
          <li><a class="nav-link scrollto" href="index.php">Login</a></li>
          <li><a class="nav-link scrollto active" href="signup.php">Sign Up</a></li>
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav><!-- .navbar -->

    </div>
  </header>

    <div class="container d-flex justify-content-center align-items-center"
      style="min-height: 90vh"> 
        <form class="border shadow p-3 rounded"
              action="php/check-signup.php"
              method="post" 
              style="width: 600px;background-color: LightGray"><br><br>
    <h1 class="text-center p-3">SIGN UP</h1>

    <?php if (isset($_GET['error'])) { ?>
      <div class="alert alert-danger" role="alert">
        <?=$_GET['error']?>
      </div>
    <?php } ?>


    <label for="name" class="form-label">Full Name</label>
    <input type="text"name="name" class="form-control" id="name">
    
    <label for="username" class="form-label">User name</label>
    <input type="text" class="form-control" name="username" id="username">
    
    <label for="password" class="form-label">Password</label>
    <input type="password"name="password" class="form-control" id="password">
    
    <label for="re_password" class="form-label">Re-Password</label> 
    <input type="password" name="re_password" class="form-control" id="re_password">
    
    <label for="matric" class="form-label">Matric Number</label>
    <input type="matric" name="matric" class="form-control" id="matric">

    <label class="form-label">Status</label>
    <select class="form-select mb-3" name="role" id="role" aria-label="Default select example">
    <option selected value="student">Student</option>
    </select>

    <label class="form-label">Faculty</label>
    <select class="form-select mb-3" name="faculty" id="faculty" aria-label="Default select example">
    <option selected value="Faculty of Built Environment">Faculty of Built Environment</option>
    <option selected value="Faculty of Language and Linguistics">Faculty of Language & Linguistics</option>
    <option selected value="Faculty of Economics and Administration">Faculty of Economics $ Administration</option>
    <option selected value="Faculty of Pharmacy">Faculty of Pharmacy</option>
    <option selected value="Faculty of Engineering">Faculty of Engineering</option>
    <option selected value="Faculty of Education">Faculty of Education</option>
    <option selected value="Faculty of Dentistry">Faculty of Dentistry</option>
    <option selected value="Faculty of Business and Accountancy">Faculty of Business & Accountancy</option>
    <option selected value="Faculty of Medicine">Faculty of Medicine</option>
    <option selected value="Faculty of Science">Faculty of Science</option>
    <option selected value="Faculty of Computer Science & Information Technology">Faculty of Computer Science & Information Technology</option>
    <option selected value="Faculty of Arts and Social Sciences">Faculty of Arts & Social Sciences</option>
    <option selected value="Faculty of Creative Arts">Faculty of Creative Arts</option>
    <option selected value="Faculty of Law">Faculty of Law</option>
    </select> 

    <label class="form-label">Department</label>
    <select class="form-select mb-3" name="department" id="department" aria-label="Default select example">
    <option selected value="Architecture">Architecture</option>
    <option selected value="Building Surveying">Building Surveying</option>
    <option selected value="Real Estate"> Real Estate</option>
    <option selected value="Quantity Surveying">Quantity Surveying</option>
    <option selected value="Urban and Regional Planning">Urban & Regional Planning</option>
    <option selected value="Real Estate"> Real Estate</option>
    <option selected value="English Languages"> English Language</option>
    <option selected value="Asean and European Languages"> Asean and European Languages</option>
    <option selected value="Malaysian Languages and Applied Linguistics">Malaysian Languages and Applied Linguistics</option>
    <option selected value="Arabic and Middle Eastern Languages">Arabic and Middle Eastern Languages</option>

    </select> 

    <label class="form-label">Program</label>
    <select class="form-select mb-3" name="program" id="program" aria-label="Default select example">
    <option selected value="Bachelor of Science in Architecture">Bachelor of Science in Architecture</option>
    <option selected value="Bachelor of Building Surveying">Bachelor of Building Surveying</option>
    <option selected value="Bachelor of Quantity Surveying">Bachelor of Quantity Surveying</option>
    <option selected value="Bachelor of Real Estate">Bachelor of Real Estate</option>
    <option selected value="Bachelor of Urban and Regional Planning">Bachelor of Urban & Regional Planning</option>
    <option selected value="Bachelor of Arabic Language and Linguistics">Bachelor of Arabic Language and Linguistics</option>
    <option selected value="Bachelor of Chinese Language and Linguistics">Bachelor of Chinese Language and Linguistics</option>
    <option selected value="Bachelor of English Language and Linguistics">Bachelor of English Language and Linguistics</option>
    <option selected value="Bachelor of French Language and Linguistics">Bachelor of French Language and Linguistics</option>
    <option selected value="Bachelor of German Language and Linguistics">Bachelor of German Language and Linguistics</option>
    <option selected value="Bachelor of Japanese Language and Linguistics">Bachelor of Japanese Language and Linguistics</option>
    <option selected value="Bachelor of Spanish Language and Linguistics">Bachelor of Spanish Language and Linguistics</option>
    <option selected value="Bachelor of Tamil Language and Linguistics">Bachelor of Tamil Language and Linguistics</option>
    <option selected value="Bachelor of Italian Language and Linguistics">Bachelor of Italian Language and Linguistics</option>

    </select> 

    <label class="form-label">Year</label>
    <select class="form-select mb-3" name="year" id="year" aria-label="Default select example">
    <option selected value="Year 1">Year 1</option>
    <option selected value="Year 2">Year 2</option>
    <option selected value="Year 3">Year 3</option>
    <option selected value="Year 4">Year 4</option>
    </select> 

<button type="submit" class="btn btn-primary">Submit</button>
<p><h6><a href="index.php">Already have account?</h6></p>
</form>
</div>
<?php include("includes/footer.php"); ?>
</body>
</html>
<?php }else{
  header("Location: profile.php");
} 
?>