<?php
session_start();
if(isset($_POST['faculty']) && isset($_POST['department']) && isset($_POST['program']) && isset($_POST['matric'])) {
include "../db_conn.php";

	function test_input($data) {
		$data = trim($data);
		$data = stripslashes($data);
		$data = htmlspecialchars($data);
		return $data;
	}

	$faculty = test_input($_POST['faculty']);
	$department = test_input($_POST['department']);
	$program = test_input($_POST['program']);
	$matric = test_input($_POST['matric']);

	if(empty($faculty) || empty($department) || empty($program) || empty($matric)) {
		
		header ("Location: ../profile.php?error=Please fill in the form");
	}else{

		$sql = "INSERT INTO form(faculty,department,program,matric) VALUES('$faculty','$department','$program','$matric')";
		$res = mysqli_query($conn, $sql);

		if($res){
			echo "Registered";
			header("Location: ../test.php");
		}else {
			header("Location: ../test.php");
		}
	}

} else {
	header("Location: ../profile.php");
}