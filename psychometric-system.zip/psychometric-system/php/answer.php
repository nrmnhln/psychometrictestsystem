<?php

if(isset($_SESSION['username']) && isset($_SESSION['id'])) {


    $matric=(int)$_SESSION['matric'];

    $sql="SELECT * from answer WHERE matric='$matric'";
	$result= mysqli_query($conn, $sql);

}else{
      header("Location: index.php");
} ?>