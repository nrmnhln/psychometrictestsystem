<?php
session_start();
include "../db_conn.php";
if (isset($_POST['username']) && isset($_POST['password']) && isset($_POST['re_password']) && isset($_POST['role']) && isset($_POST['name']) && isset($_POST['matric']) && isset($_POST['faculty']) && isset($_POST['department']) && isset($_POST['program']) && isset($_POST['year'])) {

	function test_input($data) {
		$data = trim($data);
		$data = stripslashes($data);
		$data = htmlspecialchars($data);
		return $data;
	}

	$username = test_input($_POST['username']);
	$password = test_input($_POST['password']);
	$name = test_input($_POST['name']);
	$matric = test_input($_POST['matric']);
	$role = test_input($_POST['role']);
	$re_password = test_input($_POST['re_password']);
	$faculty = test_input($_POST['faculty']);
	$department = test_input($_POST['department']);
	$program = test_input($_POST['program']);
	$year = test_input($_POST['year']);

	$user_data='username'.$username. '&name='.$name;

	if(empty($username)) {
		header("Location: ../signup.php?error=User name is required&$user_data");
	}else if($password !== $re_password) {
		header("Location: ../signup.php?error=The password does not match&$user_data");
	}else if(empty($matric)) {
		header("Location: ../signup.php?error=Matric Number is required&$user_data");
	}else if(empty($name)) {
		header("Location: ../signup.php?error=Name is required&$user_data");
	}else if(empty($re_password)) {
		header("Location: ../signup.php?error=Re_Password is required&$user_data");
	}else if(empty($role)) {
		header("Location: ../signup.php?error=Role is required&$user_data");
	}else if(empty($faculty)) {
		header("Location: ../signup.php?error=Faculty is required&$user_data");
	}else if(empty($department)) {
		header("Location: ../signup.php?error=Department is required&$user_data");
	}else if(empty($program)) {
		header("Location: ../signup.php?error=Program is required&$user_data");
	}else if(empty($year)) {
		header("Location: ../signup.php?error=Year is required&$user_data");
	}

	else {

		//hashing the password
		//$password = md5($password);

		$sql = "SELECT * FROM users WHERE username='$username'";
		$result= mysqli_query($conn, $sql);

		if(mysqli_num_rows($result) >0) {
			header("Location: ../signup.php?error=The username is taken try again&$user_data");
			exit();
		}else{
			$sql2="INSERT INTO users(username,password,name,matric,role,faculty,department,program,year) VALUES('$username','$password','$name','$matric','$role','$faculty','$department','$program','$year');INSERT INTO answer(matric) VALUES('$matric');";
			$result2= mysqli_multi_query($conn, $sql2);
			if ($result2) {
				echo '<script type="text/javascript"> alert("You account has been created! Please login to continue.")</script>';
				echo'<script> window.location="../index.php"; </script> ';
				exit;
			}else{
				header("Location: ../signup.php?error=unknown error occured&$user_data");
				exit();
			}
		}

	}
	
}else {
	header("Location: ../signup.php");
}
?>