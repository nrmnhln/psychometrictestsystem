<?php
session_start();
if(isset($_POST['question1']) && isset($_POST['question2']) && isset($_POST['question3']) && isset($_POST['question4'])) {
include "../db_conn.php";

	function test_input($data) {
		$data = trim($data);
		$data = stripslashes($data);
		$data = htmlspecialchars($data);
		return $data;
	}

	$question1 = test_input($_POST['question1']);
	$question2 = test_input($_POST['question2']);
	$question3 = test_input($_POST['question3']);
	$question4 = test_input($_POST['question4']);

	if(empty($question1) || empty($question2) || empty($question3) || empty($question4)) {
		
		header ("Location: ../test.php?error=Please fill in the form");

	}else {

		$sql ="INSERT INTO question(question1,question2,question3,question4) VALUES('$question1','$question2','$question3','$question4')";
		$res1 = mysqli_query($conn, $sql);
	}

} else {
	header("Location: ../profile.php");
}