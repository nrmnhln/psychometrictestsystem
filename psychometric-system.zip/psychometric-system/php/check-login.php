<?php
session_start();
include "../db_conn.php";
if (isset($_POST['username']) && isset($_POST['password']) && isset($_POST['role'])) {

	function test_input($data) {
		$data = trim($data);
		$data = stripslashes($data);
		$data = htmlspecialchars($data);
		return $data;
	}

	$username = test_input($_POST['username']);
	$password = test_input($_POST['password']);
	$role = test_input($_POST['role']);

	if(empty($username)) {
		header("Location: ../index.php?error=User name is required");
	}else if(empty($password)) {
		header("Location: ../index.php?error=Password is required");
	}else {

		//hashing the password
		//$password = md5($password);

		$sql = "SELECT * FROM users WHERE username='$username' AND password= '$password'";
		$result= mysqli_query($conn, $sql);

		if(mysqli_num_rows($result) === 1) {
			//user name unique 
			$row = mysqli_fetch_assoc($result);
			if($row['password'] === $password && $row['role'] == $role) {
				$_SESSION['name'] = $row['name'];
				$_SESSION['id'] = $row['id'];
				$_SESSION['role'] = $row['role'];
				$_SESSION['username'] = $row['username'];
				$_SESSION['faculty'] = $row['faculty'];
				$_SESSION['department'] = $row['department'];
				$_SESSION['program'] = $row['program'];
				$_SESSION['matric'] = $row['matric'];

				if($_SESSION['role'] == 'admin'){
					header("Location: ../adminhome.php");

				}else{
					
					header("Location: ../home.php");	
				}

			}else {
				header("Location: ../index.php?error=Incorrect username or password");
			}
		}else {
			header("Location: ../index.php?error=Incorrect username or password");
		}

	}
	
}else {
	header("Location: ../index.php");
}
?>