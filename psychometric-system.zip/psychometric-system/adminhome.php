<?php
session_start();
include "db_conn.php";
if(isset($_SESSION['username']) && isset($_SESSION['role'])) {  ?>

<!DOCTYPE html>
<html lang="en">

<?php include("includes/head.php"); ?>

<body>

    <!-- ======= Header ======= -->
  <header id="header" class="fixed-top d-flex align-items-center">
    <div class="container d-flex align-items-center">

      <div class="logo me-auto">
        <h1><a href="test.php">Universiti Malaya</a></h1>
      </div>

      <nav id="navbar" class="navbar order-last order-lg-0">
        <ul>
          <li><a class="nav-link scrollto active" href="#admin">Home</a></li>
          <li><a class="nav-link scrollto" href="adminprofile.php">Student</a></li>
          <li class="dropdown"><a class="nav-link scrollto" href="#"><span>Manage Test</span><i class="bi bi-chevron-down"></i></a>
            <ul>
              <!-- <li><a href="addQuestion.php">Add Question</a></li> -->
              <li><a href="editQuestion.php">Edit Question</a></li>
            </ul>
          </li>
          <li><a class="nav-link scrollto" href="logout.php">Logout</a></li>
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav><!-- .navbar -->

    </div>
  </header>

  <!-- ======= Hero Section ======= -->
  <section id="hero" class="d-flex flex-column justify-content-center align-items-center">
    <div class="container text-center text-md-left" data-aos="fade-up">
      <h1>Psychometric Test</h1>
      <h2>Your personality matters</h2>
    </div>
  </section><!-- End Hero -->

  <main id="main">

    <!-- ======= Portfolio Section ======= -->
    <section id="portfolio" class="portfolio">
      <div class="container">

        <div class="section-title">
          <h2>Welcome</h2>
        </div>

        <div class="row portfolio-container">

          <div class="col-lg-4 col-md-6 portfolio-item filter-app wow fadeInUp">
            <div class="portfolio-wrap">
              <figure>
                <img src="img/chart.jpg" class="img-fluid" alt="">
                <a href="#1" class="link-details" title="More Details"><i class="bx bx-link"></i></a>
              </figure>

              <div class="portfolio-info">
                <h4><a href="report.php">Report</a></h4>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 portfolio-item filter-app wow fadeInUp">
            <div class="portfolio-wrap">
              <figure>
                <img src="img/students.jpg" class="img-fluid" alt="">
                <a href="#1" class="link-details" title="More Details"><i class="bx bx-link"></i></a>
              </figure>

              <div class="portfolio-info">
                <h4><a href="adminprofile.php">Students</a></h4>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 portfolio-item filter-app wow fadeInUp">
            <div class="portfolio-wrap">
              <figure>
                <img src="img/about-bg.jpg" class="img-fluid" alt="">
                <a href="#1" class="link-details" title="More Details"><i class="bx bx-link"></i></a>
              </figure>

              <div class="portfolio-info">
                <h4><a href="editQuestion.php">Manage Test</a></h4>
              </div>
            </div>
          </div>

          

        </div>

      </div>
    </section><!-- End Portfolio Section -->


  </main><!-- End #main -->

  <?php include("includes/footer.php"); ?>

</body>

</html>
<?php }else{
      header("Location: index.php");
} ?>