<?php
session_start();
include "db_conn.php";
if(!isset($_SESSION['username']) && !isset($_SESSION['id'])) {  ?>

<!DOCTYPE html>
<html>

<?php include("includes/head.php"); ?>

<body>
       <!-- ======= Header ======= -->
  <header id="header" class="fixed-top d-flex align-items-center">
    <div class="container d-flex align-items-center">

      <div class="logo me-auto">
        <h1><a href="test.php">Universiti Malaya</a></h1>
        <!-- Uncomment below if you prefer to use an image logo -->
        <!-- <a href="index.html"><img src="assets/img/logo.png" alt="" class="img-fluid"></a>-->
      </div>

      <nav id="navbar" class="navbar order-last order-lg-0">
        <ul>
          <li><a class="nav-link scrollto active" href="index.php">Login</a></li>
          <li><a class="nav-link scrollto" href="signup.php">Sign Up</a></li>
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav><!-- .navbar -->

    </div>
  </header>

      <div class="container d-flex justify-content-center align-items-center"
      style="min-height: 100vh"> 
      	<form class="border shadow p-3 rounded"
      	      action="php/check-login.php"
      	      method="post" 
      	      style="width: 450px;background-color: LightGray">
      	      <h1 class="text-center p-3">LOGIN</h1>

      	      <?php if (isset($_GET['error'])) { ?>
      	      <div class="alert alert-danger" role="alert">
      	      	  <?=$_GET['error']?>
      	      </div>
      	      <?php } ?>

      		<div class="mb-3">
      			<label for="username" 
      			       class="form-label">User name</label>
      			<input type="text" 
      			       class="form-control" 
      			       name="username" 
      			       id="username">
      		</div>
      		<div class="mb-3">
      			<label for="password" 
      			       class="form-label">Password</label>
      			<input type="password"
      			       name="password" 
      			       class="form-control" 
      			       id="password">
      		</div>
      		<div class="mb-1">
      			<label class="form-label">Status</label>
      		</div>
      		<select class="form-select mb-3"
      		        name="role" 
      		        aria-label="Default select example">
      			<option selected value="student">Student</option>
      			<option value="admin">Admin</option>
      		</select> 
      		<button type="submit" class="btn btn-primary">Submit</button>
                  <p><h6><a href="signup.php">Do not have account yet? Register here.</h6></p>
      	</form>
      </div>
<?php include("includes/footer.php"); ?>
</body>
</html>
<?php }else{
      header("Location: profile.php");
} 
?>