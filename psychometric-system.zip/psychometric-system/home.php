<?php
session_start();
include "db_conn.php";
if(isset($_SESSION['username']) && isset($_SESSION['role'])) {  ?>

  <!DOCTYPE html>
  <html lang="en">

  <?php include("includes/head.php"); ?>

  <body>

    <?php include("includes/header.php"); ?>

    <?php include("includes/main.php"); ?>

    <?php include("includes/footer.php"); ?>

  </body>

  </html>
<?php }else{
  header("Location: index.php");
} ?>