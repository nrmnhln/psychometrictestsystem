<?php
include "db_conn.php";

$sql="SELECT * FROM answer";
$fire=mysqli_query($conn,$sql);


$query=$conn->query("select * from soalan where no_soalan='29'");
$res29=$query->fetch_array();

$query=$conn->query("select * from soalan where no_soalan='30'");
$res30=$query->fetch_array();

$query=$conn->query("select * from soalan where no_soalan='31'");
$res31=$query->fetch_array();

$query=$conn->query("select * from soalan where no_soalan='32'");
$res32=$query->fetch_array();

$query=$conn->query("select * from soalan where no_soalan='33'");
$res33=$query->fetch_array();

$query=$conn->query("select * from soalan where no_soalan='34'");
$res34=$query->fetch_array();

?>
<html>
<head>

  <title>psychometric-system</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">
  <script type="text/javascript" src="test.js"></script>

  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Psychometric - Index</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

  <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>

  <?php include("includes/style.php"); ?>

  <script type="text/javascript">
    google.charts.load('current', {'packages':['bar']});
    google.charts.setOnLoadCallback(drawChart);

    function drawChart() {
      var data = google.visualization.arrayToDataTable([
        ['Value', 'count'],
        <?php

        $query="SELECT likert.id AS answer29, COUNT(answer.qid) AS count FROM answer RIGHT JOIN likert ON likert.id=answer.answer29 GROUP BY likert.id";
        $query_result=mysqli_query($conn,$query);

        while ($result1=mysqli_fetch_assoc($query_result)) {
          
          echo "['".$result1['answer29']."',".$result1['count']."],";
          
        }
        ?>
        ]);

      var options = {
        chart: {
          title: '29.<?php echo $res29['soalan']; ?>',
        }
      };

      var chart = new google.charts.Bar(document.getElementById('graf29'));

      chart.draw(data, google.charts.Bar.convertOptions(options));
    }
  </script>

  <script type="text/javascript">
    google.charts.load('current', {'packages':['bar']});
    google.charts.setOnLoadCallback(drawChart);

    function drawChart() {
      var data = google.visualization.arrayToDataTable([
        ['Value', 'count'],
        <?php

        $query="SELECT likert.id AS answer30, COUNT(answer.qid) AS count FROM answer RIGHT JOIN likert ON likert.id=answer.answer30 GROUP BY likert.id";
        $query_result=mysqli_query($conn,$query);

        while ($result1=mysqli_fetch_assoc($query_result)) {
          
          echo "['".$result1['answer30']."',".$result1['count']."],";
          
        }
        ?>
        ]);

      var options = {
        chart: {
          title: '30.<?php echo $res30['soalan']; ?>',
        }
      };

      var chart = new google.charts.Bar(document.getElementById('graf30'));

      chart.draw(data, google.charts.Bar.convertOptions(options));
    }
  </script>

  <script type="text/javascript">
    google.charts.load('current', {'packages':['bar']});
    google.charts.setOnLoadCallback(drawChart);

    function drawChart() {
      var data = google.visualization.arrayToDataTable([
        ['Value', 'count'],
        <?php

        $query="SELECT likert.id AS answer31, COUNT(answer.qid) AS count FROM answer RIGHT JOIN likert ON likert.id=answer.answer31 GROUP BY likert.id";
        $query_result=mysqli_query($conn,$query);

        while ($result1=mysqli_fetch_assoc($query_result)) {
          
          echo "['".$result1['answer31']."',".$result1['count']."],";
          
        }
        ?>
        ]);

      var options = {
        chart: {
          title: '31.<?php echo $res31['soalan']; ?>',
        }
      };

      var chart = new google.charts.Bar(document.getElementById('graf31'));

      chart.draw(data, google.charts.Bar.convertOptions(options));
    }
  </script>

  <script type="text/javascript">
    google.charts.load('current', {'packages':['bar']});
    google.charts.setOnLoadCallback(drawChart);

    function drawChart() {
      var data = google.visualization.arrayToDataTable([
        ['Value', 'count'],
        <?php

        $query="SELECT likert.id AS answer32, COUNT(answer.qid) AS count FROM answer RIGHT JOIN likert ON likert.id=answer.answer32 GROUP BY likert.id";
        $query_result=mysqli_query($conn,$query);

        while ($result1=mysqli_fetch_assoc($query_result)) {
          
          echo "['".$result1['answer32']."',".$result1['count']."],";
          
        }
        ?>
        ]);

      var options = {
        chart: {
          title: '32. <?php echo $res32['soalan']; ?>',
        }
      };

      var chart = new google.charts.Bar(document.getElementById('graf32'));

      chart.draw(data, google.charts.Bar.convertOptions(options));
    }
  </script>

  <script type="text/javascript">
    google.charts.load('current', {'packages':['bar']});
    google.charts.setOnLoadCallback(drawChart);

    function drawChart() {
      var data = google.visualization.arrayToDataTable([
        ['Value', 'count'],
        <?php

        $query="SELECT likert.id AS answer33, COUNT(answer.qid) AS count FROM answer RIGHT JOIN likert ON likert.id=answer.answer33 GROUP BY likert.id";
        $query_result=mysqli_query($conn,$query);

        while ($result1=mysqli_fetch_assoc($query_result)) {
          
          echo "['".$result1['answer33']."',".$result1['count']."],";
          
        }
        ?>
        ]);

      var options = {
        chart: {
          title: '33.<?php echo $res33['soalan']; ?>',
        }
      };

      var chart = new google.charts.Bar(document.getElementById('graf33'));

      chart.draw(data, google.charts.Bar.convertOptions(options));
    }
  </script>

  <script type="text/javascript">
    google.charts.load('current', {'packages':['bar']});
    google.charts.setOnLoadCallback(drawChart);

    function drawChart() {
      var data = google.visualization.arrayToDataTable([
        ['Value', 'count'],
        <?php

        $query="SELECT likert.id AS answer34, COUNT(answer.qid) AS count FROM answer RIGHT JOIN likert ON likert.id=answer.answer34 GROUP BY likert.id";
        $query_result=mysqli_query($conn,$query);

        while ($result1=mysqli_fetch_assoc($query_result)) {
          
          echo "['".$result1['answer34']."',".$result1['count']."],";
          
        }
        ?>
        ]);

      var options = {
        chart: {
          title: '34.<?php echo $res34['soalan']; ?>',
        }
      };

      var chart = new google.charts.Bar(document.getElementById('graf34'));

      chart.draw(data, google.charts.Bar.convertOptions(options));
    }
  </script>

</head>

<body>
  <header id="header" class="fixed-top d-flex align-items-center">
    <div class="container d-flex align-items-center">

      <div class="logo me-auto">
        <h1><a href="test.php">Universiti Malaya</a></h1>
        <!-- Uncomment below if you prefer to use an image logo -->
        <!-- <a href="index.html"><img src="assets/img/logo.png" alt="" class="img-fluid"></a>-->
      </div>

      <nav id="navbar" class="navbar order-last order-lg-0">
        <ul>
          <li><a class="nav-link scrollto" href="adminhome.php">Home</a></li>
          <li><a class="nav-link scrollto" href="adminprofile.php">Student</a></li>          
          <li class="dropdown"><a class="nav-link scrollto" href="#"><span>Manage Test</span><i class="bi bi-chevron-down"></i></a>
            <ul>
              <!-- <li><a href="addQuestion.php">Add Question</a></li> -->
              <li><a href="editQuestion.php">Edit Question</a></li>
            </ul>
          </li>
          <li><a class="nav-link scrollto" href="logout.php">Logout</a></li>
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav><!-- .navbar -->

    </div>
  </header>  

  
  <!-- ======= Portfolio Section ======= -->
  <section id="portfolio" class="portfolio">
    <div class="container">

      <div class="section-title">
        <h2>REPORT</h2>
        <p><h4>Graph for COMMUNICATION</h4></p>
      </div>

      <div style="text-align: center;">
      <div id="graf29"style="text-align: center;width: 700px; height: 400px;margin: 70 auto;"></div>
      <div id="graf30"style="text-align: center;width: 700px;height: 400px; margin: 80 auto;"></div>
      <div id="graf31"style="text-align: center;width: 700px;height: 400px; margin: 80 auto;"></div>
      <div id="graf32"style="text-align: center;width: 700px;height: 400px; margin: 80 auto;"></div>
      <div id="graf33"style="text-align: center;width: 700px;height: 400px; margin: 80 auto;"></div>
      <div id="graf34"style="text-align: center;width: 700px;height: 400px; margin: 0 auto;"></div>

      <!-- <div class="p-3" id="graf29" style="width: 800px; height: 400px;"></div><br>

      <div class="p-3" id="graf30" style="width: 800px; height: 400px;"></div><br>

      <div class="p-3" id="graf31" style="width: 800px; height: 400px;"></div><br>

      <div class="p-3" id="graf32" style="width: 800px; height: 400px;"></div><br>

      <div class="p-3" id="graf33" style="width: 800px; height: 400px;"></div><br>

      <div class="p-3" id="graf34" style="width: 800px; height: 400px;"></div> -->

      <button style="margin-left:auto;margin-right:auto;display:block;margin-top:9%;"class="button button1"><a href="report.php">Back</button>
</div>
    </div>
  </section><!-- End Portfolio Section -->

<?php include("includes/footer.php"); ?>

</body>
</html>

