<?php
include "db_conn.php";

$sql="SELECT * FROM answer";
$fire=mysqli_query($conn,$sql);


$query=$conn->query("select * from soalan where no_soalan='35'");
$res35=$query->fetch_array();

$query=$conn->query("select * from soalan where no_soalan='36'");
$res36=$query->fetch_array();

$query=$conn->query("select * from soalan where no_soalan='37'");
$res37=$query->fetch_array();

$query=$conn->query("select * from soalan where no_soalan='38'");
$res38=$query->fetch_array();

$query=$conn->query("select * from soalan where no_soalan='39'");
$res39=$query->fetch_array();

$query=$conn->query("select * from soalan where no_soalan='40'");
$res40=$query->fetch_array();

?>
<html>
<head>

  <title>psychometric-system</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">
  <script type="text/javascript" src="test.js"></script>

  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Psychometric - Index</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

  <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>

  <?php include("includes/style.php"); ?>

  <script type="text/javascript">
    google.charts.load('current', {'packages':['bar']});
    google.charts.setOnLoadCallback(drawChart);

    function drawChart() {
      var data = google.visualization.arrayToDataTable([
        ['Value', 'count'],
        <?php

        $query="SELECT likert.id AS answer35, COUNT(answer.qid) AS count FROM answer RIGHT JOIN likert ON likert.id=answer.answer35 GROUP BY likert.id";
        $query_result=mysqli_query($conn,$query);

        while ($result1=mysqli_fetch_assoc($query_result)) {
          
          echo "['".$result1['answer35']."',".$result1['count']."],";
          
        }
        ?>
        ]);

      var options = {
        chart: {
          title: '35.<?php echo $res35['soalan']; ?>',
        }
      };

      var chart = new google.charts.Bar(document.getElementById('graf35'));

      chart.draw(data, google.charts.Bar.convertOptions(options));
    }
  </script>

  <script type="text/javascript">
    google.charts.load('current', {'packages':['bar']});
    google.charts.setOnLoadCallback(drawChart);

    function drawChart() {
      var data = google.visualization.arrayToDataTable([
        ['Value', 'count'],
        <?php

        $query="SELECT likert.id AS answer36, COUNT(answer.qid) AS count FROM answer RIGHT JOIN likert ON likert.id=answer.answer36 GROUP BY likert.id";
        $query_result=mysqli_query($conn,$query);

        while ($result1=mysqli_fetch_assoc($query_result)) {
          
          echo "['".$result1['answer36']."',".$result1['count']."],";
          
        }
        ?>
        ]);

      var options = {
        chart: {
          title: '36.<?php echo $res36['soalan']; ?>',
        }
      };

      var chart = new google.charts.Bar(document.getElementById('graf36'));

      chart.draw(data, google.charts.Bar.convertOptions(options));
    }
  </script>

  <script type="text/javascript">
    google.charts.load('current', {'packages':['bar']});
    google.charts.setOnLoadCallback(drawChart);

    function drawChart() {
      var data = google.visualization.arrayToDataTable([
        ['Value', 'count'],
        <?php

        $query="SELECT likert.id AS answer37, COUNT(answer.qid) AS count FROM answer RIGHT JOIN likert ON likert.id=answer.answer37 GROUP BY likert.id";
        $query_result=mysqli_query($conn,$query);

        while ($result1=mysqli_fetch_assoc($query_result)) {
          
          echo "['".$result1['answer37']."',".$result1['count']."],";
          
        }
        ?>
        ]);

      var options = {
        chart: {
          title: "37.<?php echo $res37['soalan']; ?>",
        }
      };

      var chart = new google.charts.Bar(document.getElementById('graf37'));

      chart.draw(data, google.charts.Bar.convertOptions(options));
    }
  </script>

  <script type="text/javascript">
    google.charts.load('current', {'packages':['bar']});
    google.charts.setOnLoadCallback(drawChart);

    function drawChart() {
      var data = google.visualization.arrayToDataTable([
        ['Value', 'count'],
        <?php

        $query="SELECT likert.id AS answer38, COUNT(answer.qid) AS count FROM answer RIGHT JOIN likert ON likert.id=answer.answer38 GROUP BY likert.id";
        $query_result=mysqli_query($conn,$query);

        while ($result1=mysqli_fetch_assoc($query_result)) {
          
          echo "['".$result1['answer38']."',".$result1['count']."],";
          
        }
        ?>
        ]);

      var options = {
        chart: {
          title: '38.<?php echo $res38['soalan']; ?>',
        }
      };

      var chart = new google.charts.Bar(document.getElementById('graf38'));

      chart.draw(data, google.charts.Bar.convertOptions(options));
    }
  </script>

  <script type="text/javascript">
    google.charts.load('current', {'packages':['bar']});
    google.charts.setOnLoadCallback(drawChart);

    function drawChart() {
      var data = google.visualization.arrayToDataTable([
        ['Value', 'count'],
        <?php

        $query="SELECT likert.id AS answer39, COUNT(answer.qid) AS count FROM answer RIGHT JOIN likert ON likert.id=answer.answer39 GROUP BY likert.id";
        $query_result=mysqli_query($conn,$query);

        while ($result1=mysqli_fetch_assoc($query_result)) {
          
          echo "['".$result1['answer39']."',".$result1['count']."],";
          
        }
        ?>
        ]);

      var options = {
        chart: {
          title: '39.<?php echo $res39['soalan']; ?>',
        }
      };

      var chart = new google.charts.Bar(document.getElementById('graf39'));

      chart.draw(data, google.charts.Bar.convertOptions(options));
    }
  </script>

  <script type="text/javascript">
    google.charts.load('current', {'packages':['bar']});
    google.charts.setOnLoadCallback(drawChart);

    function drawChart() {
      var data = google.visualization.arrayToDataTable([
        ['Value', 'count'],
        <?php

        $query="SELECT likert.id AS answer40, COUNT(answer.qid) AS count FROM answer RIGHT JOIN likert ON likert.id=answer.answer40 GROUP BY likert.id";
        $query_result=mysqli_query($conn,$query);

        while ($result1=mysqli_fetch_assoc($query_result)) {
          
          echo "['".$result1['answer40']."',".$result1['count']."],";
          
        }
        ?>
        ]);

      var options = {
        chart: {
          title: '40.<?php echo $res40['soalan']; ?>',
        }
      };

      var chart = new google.charts.Bar(document.getElementById('graf40'));

      chart.draw(data, google.charts.Bar.convertOptions(options));
    }
  </script>

</head>

<body>
  <header id="header" class="fixed-top d-flex align-items-center">
    <div class="container d-flex align-items-center">

      <div class="logo me-auto">
        <h1><a href="test.php">Universiti Malaya</a></h1>
        <!-- Uncomment below if you prefer to use an image logo -->
        <!-- <a href="index.html"><img src="assets/img/logo.png" alt="" class="img-fluid"></a>-->
      </div>

      <nav id="navbar" class="navbar order-last order-lg-0">
        <ul>
          <li><a class="nav-link scrollto" href="adminhome.php">Home</a></li>
          <li><a class="nav-link scrollto" href="adminprofile.php">Student</a></li>          
          <li class="dropdown"><a class="nav-link scrollto" href="#"><span>Manage Test</span><i class="bi bi-chevron-down"></i></a>
            <ul>
              <!-- <li><a href="addQuestion.php">Add Question</a></li> -->
              <li><a href="editQuestion.php">Edit Question</a></li>
            </ul>
          </li>
          <li><a class="nav-link scrollto" href="logout.php">Logout</a></li>
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav><!-- .navbar -->

    </div>
  </header>  

  
  <!-- ======= Portfolio Section ======= -->
  <section id="portfolio" class="portfolio">
    <div class="container">

      <div class="section-title">
        <h2>REPORT</h2>
        <p><h4>Graph for TEAMWORK</h4></p>
      </div>

      <div style="text-align: center;">
      <div id="graf35"style="text-align: center;width: 700px; height: 400px;margin: 70 auto;"></div>
      <div id="graf36"style="text-align: center;width: 700px;height: 400px; margin: 80 auto;"></div>
      <div id="graf37"style="text-align: center;width: 700px;height: 400px; margin: 80 auto;"></div>
      <div id="graf38"style="text-align: center;width: 700px;height: 400px; margin: 80 auto;"></div>
      <div id="graf39"style="text-align: center;width: 700px;height: 400px; margin: 80 auto;"></div>
      <div id="graf40"style="text-align: center;width: 700px;height: 400px; margin: 0 auto;"></div>

      <!-- <div class="p-3" id="graf35" style="width: 800px; height: 400px;"></div><br>

      <div class="p-3" id="graf36" style="width: 800px; height: 400px;"></div><br>

      <div class="p-3" id="graf37" style="width: 800px; height: 400px;"></div><br>

      <div class="p-3" id="graf38" style="width: 800px; height: 400px;"></div><br>

      <div class="p-3" id="graf39" style="width: 800px; height: 400px;"></div><br>

      <div class="p-3" id="graf40" style="width: 800px; height: 400px;"></div> -->

      <button style="margin-left:auto;margin-right:auto;display:block;margin-top:9%;"class="button button1"><a href="report.php">Back</button>
</div>
    </div>
  </section><!-- End Portfolio Section -->

<?php include("includes/footer.php"); ?>

</body>
</html>

