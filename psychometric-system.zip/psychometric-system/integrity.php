<?php
include "db_conn.php";

$sql="SELECT * FROM answer";
$fire=mysqli_query($conn,$sql);

$query=$conn->query("select * from soalan where no_soalan='1'");
$res1=$query->fetch_array();

$query=$conn->query("select * from soalan where no_soalan='2'");
$res2=$query->fetch_array();

$query=$conn->query("select * from soalan where no_soalan='3'");
$res3=$query->fetch_array();

$query=$conn->query("select * from soalan where no_soalan='4'");
$res4=$query->fetch_array();

$query=$conn->query("select * from soalan where no_soalan='5'");
$res5=$query->fetch_array();

?>
<html>
<head>

  <title>psychometric-system</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">
  <script type="text/javascript" src="test.js"></script>

  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Psychometric - Index</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

  <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
  
  <script type="text/javascript">
    google.charts.load('current', {'packages':['bar']});
    google.charts.setOnLoadCallback(drawChart);

    function drawChart() {
      var data = google.visualization.arrayToDataTable([
        ['Value', 'count'],
        <?php

        $query="SELECT likert.id AS answer1, COUNT(answer.qid) AS count FROM answer RIGHT JOIN likert ON likert.id=answer.answer1 GROUP BY likert.id";
        $query_result=mysqli_query($conn,$query);

        while ($result1=mysqli_fetch_assoc($query_result)) {
          
          echo "['".$result1['answer1']."',".$result1['count']."],";
          
        }
        ?>
        ]);

      var options = {
        chart: {
          title: '1. <?php echo $res1['soalan']; ?>',
        }
      };

      var chart = new google.charts.Bar(document.getElementById('graf1'));

      chart.draw(data, google.charts.Bar.convertOptions(options));
    }
  </script>

  <script type="text/javascript">
    google.charts.load('current', {'packages':['bar']});
    google.charts.setOnLoadCallback(drawChart);

    function drawChart() {
      var data = google.visualization.arrayToDataTable([
        ['Value', 'count'],
        <?php

        $query="SELECT likert.id AS answer2, COUNT(answer.qid) AS count FROM answer RIGHT JOIN likert ON likert.id=answer.answer2 GROUP BY likert.id";
        $query_result=mysqli_query($conn,$query);

        while ($result1=mysqli_fetch_assoc($query_result)) {
          
          echo "['".$result1['answer2']."',".$result1['count']."],";
          
        }
        ?>
        ]);

      var options = {
        chart: {
          title: '2.<?php echo $res2['soalan']; ?>',
        }
      };

      var chart = new google.charts.Bar(document.getElementById('graf2'));

      chart.draw(data, google.charts.Bar.convertOptions(options));
    }
  </script>

  <script type="text/javascript">
    google.charts.load('current', {'packages':['bar']});
    google.charts.setOnLoadCallback(drawChart);

    function drawChart() {
      var data = google.visualization.arrayToDataTable([
        ['Value', 'count'],
        <?php

        $query="SELECT likert.id AS answer3, COUNT(answer.qid) AS count FROM answer RIGHT JOIN likert ON likert.id=answer.answer3 GROUP BY likert.id";
        $query_result=mysqli_query($conn,$query);

        while ($result1=mysqli_fetch_assoc($query_result)) {
          
          echo "['".$result1['answer3']."',".$result1['count']."],";
          
        }
        ?>
        ]);

      var options = {
        chart: {
          title: '3.<?php echo $res3['soalan']; ?>',
        }
      };

      var chart = new google.charts.Bar(document.getElementById('columnchart_material'));

      chart.draw(data, google.charts.Bar.convertOptions(options));
    }
  </script>

  <script type="text/javascript">
    google.charts.load('current', {'packages':['bar']});
    google.charts.setOnLoadCallback(drawChart);

    function drawChart() {
      var data = google.visualization.arrayToDataTable([
        ['Value', 'count'],
        <?php

        $query="SELECT likert.id AS answer4, COUNT(answer.qid) AS count FROM answer RIGHT JOIN likert ON likert.id=answer.answer4 GROUP BY likert.id";
        $query_result=mysqli_query($conn,$query);

        while ($result1=mysqli_fetch_assoc($query_result)) {
          
          echo "['".$result1['answer4']."',".$result1['count']."],";
          
        }
        ?>
        ]);

      var options = {
        chart: {
          title: '4.<?php echo $res4['soalan']; ?>',
        }
      };

      var chart = new google.charts.Bar(document.getElementById('columnchart_material1'));

      chart.draw(data, google.charts.Bar.convertOptions(options));
    }
  </script>

  <script type="text/javascript">
    google.charts.load('current', {'packages':['bar']});
    google.charts.setOnLoadCallback(drawChart);

    function drawChart() {
      var data = google.visualization.arrayToDataTable([
        ['Value', 'count'],
        <?php

        $query="SELECT likert.id AS answer5, COUNT(answer.qid) AS count FROM answer RIGHT JOIN likert ON likert.id=answer.answer5 GROUP BY likert.id";
        $query_result=mysqli_query($conn,$query);

        while ($result1=mysqli_fetch_assoc($query_result)) {
          
          echo "['".$result1['answer5']."',".$result1['count']."],";
          
        }
        ?>
        ]);

      var options = {
        chart: {
          title: '5.<?php echo $res5['soalan']; ?>',
        }
      };

      var chart = new google.charts.Bar(document.getElementById('columnchart_material2'));

      chart.draw(data, google.charts.Bar.convertOptions(options));
    }
  </script>

<?php include("includes/style.php"); ?>


</head>
<body>
  <header id="header" class="fixed-top d-flex align-items-center">
    <div class="container d-flex align-items-center">

      <div class="logo me-auto">
        <h1><a href="adminhome.php">Universiti Malaya</a></h1>
        <!-- Uncomment below if you prefer to use an image logo -->
        <!-- <a href="index.html"><img src="assets/img/logo.png" alt="" class="img-fluid"></a>-->
      </div>

      <nav id="navbar" class="navbar order-last order-lg-0">
        <ul>
          <li><a class="nav-link scrollto" href="adminhome.php">Home</a></li>
          <li><a class="nav-link scrollto" href="adminprofile.php">Student</a></li>          
          <li class="dropdown"><a class="nav-link scrollto" href="#"><span>Manage Test</span><i class="bi bi-chevron-down"></i></a>
            <ul>
              <!-- <li><a href="addQuestion.php">Add Question</a></li> -->
              <li><a href="editQuestion.php">Edit Question</a></li>
            </ul>
          </li>
          <li><a class="nav-link scrollto" href="logout.php">Logout</a></li>
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav><!-- .navbar -->

    </div>
  </header>  

  <!-- ======= Portfolio Section ======= -->
  <section id="portfolio" class="portfolio">
    <div class="container">

      <div class="section-title">
        <h2>REPORT</h2>
        <p><h4>Graph for INTEGRITY</h4></p>
      </div>
      
      <div style="text-align: center;">
      <div id="graf1"style="text-align: center;width: 700px; height: 400px;margin: 70 auto;"></div>
      <div id="graf2"style="text-align: center;width: 700px;height: 400px; margin: 80 auto;"></div>
      <div id="columnchart_material"style="text-align: center;width: 700px;height: 400px; margin: 80 auto;"></div>
      <div id="columnchart_material1"style="text-align: center;width: 700px;height: 400px; margin: 80 auto;"></div>
      <div id="columnchart_material2"style="text-align: center;width: 700px;height: 400px; margin: 0 auto;"></div>
      <!-- <div id="graf1" style="width: 600px; height: 400px;"></div><br>

      <div id="graf2" style="width: 800px; height: 400px;"></div><br>

      <div id="columnchart_material" style="width: 800px; height: 400px;"></div><br>
      
      <div id="columnchart_material1" style="width: 800px; height: 400px;"></div><br>
      
      <div id="columnchart_material2" style="width: 800px; height: 400px;"></div> -->

      <button style="margin-left:auto;margin-right:auto;display:block;margin-top:9%;"class="button button1"><a href="report.php">Back</button>

      <!--   <div class="align-items-center">
        <button style="margin-left:55%;margin-right:auto;display:block;margin-top:8%;"class="button button1"><a href="report.php">Integrity</button>
        <button style="margin-left:10%;margin-right:10%;display:block;margin-top:-5.5%;" class="button button1"><a href="emotional.php"> Emotional</button>
        <button style="margin-left:24%;margin-right:10%;display:block;margin-top:-5.6%;" class="button button1"><a href="emotional.php"> Adaptability</button>
          <button style="margin-left:39.5%;margin-right:10%;display:block;margin-top:-5.6%;" class="button button1"><a href="emotional.php"> Mindfulness</button>
      </div> -->

</div>
    </div>
  </section><!-- End Portfolio Section -->

<?php include("includes/footer.php"); ?>


</body>
</html>

