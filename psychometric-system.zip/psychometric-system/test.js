function check(){
	var c=0;
	var a=0;
	var q1=document.test1.question1.value;
	var q2=document.test1.question2.value;
	var q3=document.test1.question3.value;
	var q4=document.test1.question4.value;
	var q5=document.test1.question5.value;
	
	var q6=document.test1.question6.value;
	var q7=document.test1.question7.value;
	var q8=document.test1.question8.value;
	var q9=document.test1.question9.value;
	var q10=document.test1.question10.value;
	var result1=document.getElementById('result1');
	var result2=document.getElementById('result2');

	var test1=document.getElementById("test1");

	if(q1=="4") {c++}
	if(q2=="4") {c++}
	if(q3=="4") {c++}
	if(q4=="4") {c++}
	if(q5=="4") {c++}

	if(q6=="4") {a++}
	if(q7=="4") {a++}
	if(q8=="4") {a++}
	if(q9=="4") {a++}
	if(q10=="4") {a++}

	test1.style.display="none";

	if(c<=3){
    result1.textContent='INTEGRITY : Your result of integrity is '+c+'.It seems that you should make improving integrity a priority.'

    } else
        result1.textContent='INTEGRITY : Your result '+c+' is good.'
   
    if(a<=3){
    	result2.textContent='EMOTIONAL INTELLIGENCE : Your result in emotional intelligence is '+a+'. It seems that you should make improving emotional intelligence a priority.'
    } else 
        result2.textContent='EMOTIONAL INTELLIGECE : Awesome.'
        return true;

    
}
